# Como Executar o Analisador ML Pro no Seu PC

## Pré-requisitos

1. **Python 3.8 ou superior** - [Baixar aqui](https://python.org)
   - Durante a instalação, marque a opção "Add Python to PATH"
2. **Navegador web** (Chrome, Firefox, Edge)

## Passo 1: Download do Projeto

**Opção A - Download ZIP:**
1. Baixe todos os arquivos do projeto
2. Extraia para uma pasta (exemplo: `C:\ML-Analyzer`)

**Opção B - Git Clone:**
```bash
git clone [URL_DO_REPOSITORIO]
cd nome-do-projeto
```

## Passo 2: Instalação das Dependências

1. Abra o **Prompt de Comando** (cmd)
2. Navegue até a pasta do projeto:
   ```cmd
   cd C:\ML-Analyzer
   ```
3. Instale as dependências:
   ```cmd
   pip install streamlit pandas numpy matplotlib seaborn scikit-learn xgboost requests
   ```

## Passo 3: Executar a Aplicação

### Método 1 - Executável Windows (Recomendado)
1. Clique duas vezes no arquivo `ExecutarApp.bat`
2. Aguarde 30-60 segundos para carregar
3. A aplicação abrirá automaticamente no navegador
4. Se não abrir, acesse: http://localhost:5000

### Método 2 - Linha de Comando
1. No prompt, execute:
   ```cmd
   streamlit run app.py --server.port 5000
   ```
2. Acesse no navegador: http://localhost:5000

### Método 3 - Python Direto
1. Execute:
   ```cmd
   python -m streamlit run app.py --server.port 5000
   ```

## Estrutura do Projeto

```
ML-Analyzer/
├── app.py                 # Arquivo principal
├── ExecutarApp.bat        # Executável Windows
├── pages/                 # Páginas da aplicação
│   ├── 1_Exploração_de_Dados.py
│   ├── 2_Treinamento_de_Modelos.py
│   ├── 3_Comparação_de_Resultados.py
│   └── 4_Informações_Técnicas.py
├── utils/                 # Funções auxiliares
│   ├── data_loader.py
│   ├── model_trainer.py
│   ├── model_evaluation.py
│   ├── preprocess.py
│   └── visualization.py
└── .streamlit/           # Configurações
    └── config.toml
```

## Funcionalidades da Aplicação

1. **Página Inicial**: Dataset carregado automaticamente
2. **Exploração de Dados**: Análise visual e estatísticas
3. **Treinamento de Modelos**: 11 algoritmos de ML
4. **Comparação de Resultados**: Rankings e métricas
5. **Informações Técnicas**: Documentação detalhada

## Problemas Comuns e Soluções

### "Python não é reconhecido"
- Instale Python novamente marcando "Add Python to PATH"
- Ou adicione manualmente às variáveis de ambiente

### "Erro ao instalar dependências"
- Atualize o pip: `python -m pip install --upgrade pip`
- Instale uma por vez: `pip install streamlit`, `pip install pandas`, etc.

### "Porta já em uso"
- Mude a porta no comando: `--server.port 5001`
- Ou feche outras aplicações que usam a porta 5000

### Aplicação não carrega
- Aguarde até 60 segundos na primeira execução
- Verifique se todas as dependências foram instaladas
- Reinicie o prompt e tente novamente

### Performance lenta
- O treinamento dos 11 modelos demora 30-90 segundos
- Use filtros de dados para conjuntos menores se necessário

## Especificações Técnicas

- **Linguagem**: Python 3.8+
- **Framework**: Streamlit
- **ML Libraries**: Scikit-learn, XGBoost
- **Visualização**: Matplotlib, Seaborn
- **Dataset**: NYC Airbnb (15k+ registros, 16 features)
- **Modelos**: 11 algoritmos (2 obrigatórios + 9 adicionais)

## Contato e Suporte

**Desenvolvido por:**
- Vitor Correia
- Lívia Collete  
- Filipe Carreira

**Projeto Acadêmico**: Análise Comparativa de Modelos de Machine Learning

Para dúvidas técnicas, consulte a seção "Informações Técnicas" dentro da aplicação.