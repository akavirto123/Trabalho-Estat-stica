import streamlit as st
import pandas as pd
from utils.data_loader import load_data

def init_session_state():
    """
    Inicializa o estado da sessão com valores padrão e carrega o dataset automaticamente.
    """
    if 'data' not in st.session_state:
        try:
            st.session_state.data = load_data()
        except Exception as e:
            st.error(f"Erro ao carregar dataset: {str(e)}")
            st.session_state.data = None
    if 'X_train' not in st.session_state:
        st.session_state.X_train = None
    if 'X_test' not in st.session_state:
        st.session_state.X_test = None
    if 'y_train' not in st.session_state:
        st.session_state.y_train = None
    if 'y_test' not in st.session_state:
        st.session_state.y_test = None
    if 'preprocessor' not in st.session_state:
        st.session_state.preprocessor = None
    if 'model_results' not in st.session_state:
        st.session_state.model_results = {}
    if 'classification_results' not in st.session_state:
        st.session_state.classification_results = {}

def main():
    st.set_page_config(
        page_title="🏆 Analisador de Modelos ML Pro",
        page_icon="🚀",
        layout="wide",
        initial_sidebar_state="expanded"
    )
    
    # Inicializar estado da sessão
    init_session_state()
    
    # Header estilizado com animação
    st.markdown("""
        <style>
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        .header-animated {
            animation: fadeIn 1s ease-out;
        }
        .gradient-text {
            background: linear-gradient(45deg, #FF6B6B, #4ECDC4, #45B7D1);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            font-weight: bold;
        }
        .floating-emoji {
            animation: float 3s ease-in-out infinite;
        }
        @keyframes float {
            0%, 100% { transform: translateY(0px); }
            50% { transform: translateY(-10px); }
        }
        </style>
        
        <div class="header-animated" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); 
                    padding: 3rem; border-radius: 15px; margin-bottom: 2rem; box-shadow: 0 10px 30px rgba(0,0,0,0.3);">
            <h1 style="color: white; text-align: center; margin: 0; font-size: 3.5rem;">
                <span class="floating-emoji">🚀</span> Analisador de Modelos ML Pro <span class="floating-emoji">📊</span>
            </h1>
            <p style="color: #e8eaf6; text-align: center; font-size: 1.4rem; margin: 1rem 0;">
                Análise Comparativa Avançada de 11 Modelos de Aprendizado de Máquina
            </p>
            <div style="text-align: center; margin-top: 1.5rem;">
                <span style="background: rgba(255,255,255,0.2); padding: 0.5rem 1rem; border-radius: 25px; color: white; margin: 0 0.5rem;">
                    🎯 10 Modelos de Regressão
                </span>
                <span style="background: rgba(255,255,255,0.2); padding: 0.5rem 1rem; border-radius: 25px; color: white; margin: 0 0.5rem;">
                    🏆 10 Modelos de Classificação
                </span>
                <span style="background: rgba(255,255,255,0.2); padding: 0.5rem 1rem; border-radius: 25px; color: white; margin: 0 0.5rem;">
                    📈 Métricas Avançadas
                </span>
            </div>
        </div>
    """, unsafe_allow_html=True)
    
    # Créditos dos autores com cards animados
    st.markdown("""
        <style>
        .team-card {
            background: linear-gradient(145deg, #ffffff 0%, #f8f9fa 100%);
            padding: 1.5rem;
            border-radius: 15px;
            text-align: center;
            box-shadow: 0 8px 25px rgba(0,0,0,0.1);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            border: 2px solid transparent;
            background-clip: padding-box;
        }
        .team-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 35px rgba(0,0,0,0.2);
        }
        .team-card-1 { border-image: linear-gradient(45deg, #FF6B6B, #ff8a80) 1; }
        .team-card-2 { border-image: linear-gradient(45deg, #4ECDC4, #80deea) 1; }
        .team-card-3 { border-image: linear-gradient(45deg, #45B7D1, #81d4fa) 1; }
        </style>
        
        <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); 
                    padding: 2rem; border-radius: 15px; margin-bottom: 2rem;">
            <h3 style="color: white; text-align: center; margin: 0 0 2rem 0; font-size: 1.8rem;">
                👥 Equipe de Desenvolvimento
            </h3>
            <div style="display: flex; gap: 2rem; margin-top: 1rem;">
                <div class="team-card team-card-1" style="flex: 1;">
                    <div style="font-size: 3rem; margin-bottom: 1rem;">🚀</div>
                    <h4 style="color: #FF6B6B; margin: 0; font-size: 1.3rem;">Vitor Correia</h4>
                </div>
                <div class="team-card team-card-2" style="flex: 1;">
                    <div style="font-size: 3rem; margin-bottom: 1rem;">🎨</div>
                    <h4 style="color: #4ECDC4; margin: 0; font-size: 1.3rem;">Lívia Collete</h4>
                </div>
                <div class="team-card team-card-3" style="flex: 1;">
                    <div style="font-size: 3rem; margin-bottom: 1rem;">📊</div>
                    <h4 style="color: #45B7D1; margin: 0; font-size: 1.3rem;">Filipe Carreira</h4>
                </div>
            </div>
        </div>
    """, unsafe_allow_html=True)
    
    # Seção de modelos com design avançado
    st.markdown("""
        <div style="text-align: center; margin: 3rem 0 2rem 0;">
            <h2 style="color: #2c3e50; font-size: 2.5rem; margin: 0;">
                🎯 Arsenal de Modelos Implementados
            </h2>
            <p style="color: #7f8c8d; font-size: 1.2rem; margin: 1rem 0;">
                Comparação abrangente com os melhores algoritmos de aprendizado de máquina
            </p>
        </div>
    """, unsafe_allow_html=True)
    
    # Cards de modelos com efeitos visuais
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("""
            <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); 
                        padding: 2rem; border-radius: 15px; margin-bottom: 1rem; box-shadow: 0 10px 30px rgba(0,0,0,0.2);">
                <h4 style="color: white; margin: 0 0 1.5rem 0; font-size: 1.4rem; text-align: center;">
                    📊 Modelos de Regressão (10)
                </h4>
                <div style="background: rgba(255,255,255,0.1); padding: 1.5rem; border-radius: 10px;">
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; color: white;">
                        <div style="padding: 0.5rem; background: rgba(255,255,255,0.1); border-radius: 8px; text-align: center;">
                            <strong>🔢 Regressão Linear</strong><br>
                            <small>Baseline clássico</small>
                        </div>
                        <div style="padding: 0.5rem; background: rgba(255,255,255,0.1); border-radius: 8px; text-align: center;">
                            <strong>🎯 Ridge</strong><br>
                            <small>Regularização L2</small>
                        </div>
                        <div style="padding: 0.5rem; background: rgba(255,255,255,0.1); border-radius: 8px; text-align: center;">
                            <strong>🎪 Lasso</strong><br>
                            <small>Seleção automática</small>
                        </div>
                        <div style="padding: 0.5rem; background: rgba(255,255,255,0.1); border-radius: 8px; text-align: center;">
                            <strong>🌲 Random Forest</strong><br>
                            <small>Ensemble robusto</small>
                        </div>
                        <div style="padding: 0.5rem; background: rgba(255,255,255,0.1); border-radius: 8px; text-align: center;">
                            <strong>🚀 XGBoost</strong><br>
                            <small>Gradient boosting</small>
                        </div>
                        <div style="padding: 0.5rem; background: rgba(255,255,255,0.1); border-radius: 8px; text-align: center;">
                            <strong>⚡ Gradient Boost</strong><br>
                            <small>Boosting sequencial</small>
                        </div>
                        <div style="padding: 0.5rem; background: rgba(255,255,255,0.1); border-radius: 8px; text-align: center;">
                            <strong>🎪 SVR</strong><br>
                            <small>Support vectors</small>
                        </div>
                        <div style="padding: 0.5rem; background: rgba(255,255,255,0.1); border-radius: 8px; text-align: center;">
                            <strong>🔍 KNN</strong><br>
                            <small>Vizinhos próximos</small>
                        </div>
                        <div style="padding: 0.5rem; background: rgba(255,255,255,0.1); border-radius: 8px; text-align: center;">
                            <strong>🌳 Decision Tree</strong><br>
                            <small>Árvore interpretável</small>
                        </div>
                        <div style="padding: 0.5rem; background: rgba(255,255,255,0.1); border-radius: 8px; text-align: center;">
                            <strong>🧠 Rede Neural</strong><br>
                            <small>Deep learning</small>
                        </div>
                    </div>
                </div>
            </div>
        """, unsafe_allow_html=True)
    
    with col2:
        st.markdown("""
            <div style="background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%); 
                        padding: 2rem; border-radius: 15px; margin-bottom: 1rem; box-shadow: 0 10px 30px rgba(0,0,0,0.2);">
                <h4 style="color: white; margin: 0 0 1.5rem 0; font-size: 1.4rem; text-align: center;">
                    🏆 Modelos de Classificação (10)
                </h4>
                <div style="background: rgba(255,255,255,0.1); padding: 1.5rem; border-radius: 10px;">
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; color: white;">
                        <div style="padding: 0.5rem; background: rgba(255,255,255,0.1); border-radius: 8px; text-align: center;">
                            <strong>📈 Logística</strong><br>
                            <small>Classificador linear</small>
                        </div>
                        <div style="padding: 0.5rem; background: rgba(255,255,255,0.1); border-radius: 8px; text-align: center;">
                            <strong>🌲 Random Forest</strong><br>
                            <small>Ensemble classes</small>
                        </div>
                        <div style="padding: 0.5rem; background: rgba(255,255,255,0.1); border-radius: 8px; text-align: center;">
                            <strong>🚀 XGBoost</strong><br>
                            <small>Boosting classes</small>
                        </div>
                        <div style="padding: 0.5rem; background: rgba(255,255,255,0.1); border-radius: 8px; text-align: center;">
                            <strong>⚡ Gradient Boost</strong><br>
                            <small>Classificação seq.</small>
                        </div>
                        <div style="padding: 0.5rem; background: rgba(255,255,255,0.1); border-radius: 8px; text-align: center;">
                            <strong>🎯 AdaBoost</strong><br>
                            <small>Adaptive boost</small>
                        </div>
                        <div style="padding: 0.5rem; background: rgba(255,255,255,0.1); border-radius: 8px; text-align: center;">
                            <strong>⚔️ SVM</strong><br>
                            <small>Support vectors</small>
                        </div>
                        <div style="padding: 0.5rem; background: rgba(255,255,255,0.1); border-radius: 8px; text-align: center;">
                            <strong>🔍 KNN</strong><br>
                            <small>Vizinhança</small>
                        </div>
                        <div style="padding: 0.5rem; background: rgba(255,255,255,0.1); border-radius: 8px; text-align: center;">
                            <strong>🌳 Decision Tree</strong><br>
                            <small>Árvore decisão</small>
                        </div>
                        <div style="padding: 0.5rem; background: rgba(255,255,255,0.1); border-radius: 8px; text-align: center;">
                            <strong>🧠 Rede Neural</strong><br>
                            <small>Classificação NN</small>
                        </div>
                        <div style="padding: 0.5rem; background: rgba(255,255,255,0.1); border-radius: 8px; text-align: center;">
                            <strong>🎪 Elastic Net</strong><br>
                            <small>Regularização</small>
                        </div>
                    </div>
                </div>
            </div>
        """, unsafe_allow_html=True)
    
    # Métricas e features
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("""
            <div style="background: #e8f5e8; padding: 1.5rem; border-radius: 10px;">
                <h4 style="color: #2e7d32; margin: 0 0 1rem 0;">📈 Métricas de Avaliação</h4>
                <ul style="margin: 0; color: #555;">
                    <li><strong>RMSE</strong> - Root Mean Squared Error</li>
                    <li><strong>R²</strong> - Coeficiente de Determinação</li>
                    <li><strong>Explained Variance</strong> - Variância explicada</li>
                    <li><strong>Tempo de Treinamento</strong> - Performance computacional</li>
                    <li><strong>Acurácia, Precisão, Recall</strong> - Classificação</li>
                </ul>
            </div>
        """, unsafe_allow_html=True)
    
    with col2:
        st.markdown("""
            <div style="background: #fff3e0; padding: 1.5rem; border-radius: 10px;">
                <h4 style="color: #ef6c00; margin: 0 0 1rem 0;">🔧 Funcionalidades</h4>
                <ul style="margin: 0; color: #555;">
                    <li><strong>Interface Interativa</strong> - Streamlit avançado</li>
                    <li><strong>Visualizações Dinâmicas</strong> - Gráficos em tempo real</li>
                    <li><strong>Comparação Automática</strong> - Rankings de performance</li>
                    <li><strong>Exportação de Resultados</strong> - CSV e relatórios</li>
                    <li><strong>Documentação Técnica</strong> - Análise completa</li>
                </ul>
            </div>
        """, unsafe_allow_html=True)
    
    # Seção de carregamento com design interativo
    st.markdown("""
        <div style="text-align: center; margin: 3rem 0 2rem 0;">
            <h2 style="color: #2c3e50; font-size: 2.5rem; margin: 0;">
                📂 Dataset NYC Airbnb Open Data
            </h2>
            <p style="color: #7f8c8d; font-size: 1.2rem; margin: 1rem 0;">
                Dataset real com mais de 15.000 propriedades do Airbnb em Nova York
            </p>
        </div>
    """, unsafe_allow_html=True)
    
    # Container de carregamento estilizado
    st.markdown("""
        <div style="background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%); 
                    padding: 2rem; border-radius: 15px; margin-bottom: 2rem;">
            <div style="text-align: center; color: white;">
                <h3 style="margin: 0 0 1rem 0;">Dataset Carregado Automaticamente</h3>
                <p style="margin: 0; opacity: 0.9;">Explore o dataset NYC Airbnb e inicie a análise dos modelos de machine learning</p>
            </div>
        </div>
    """, unsafe_allow_html=True)
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        if st.session_state.data is not None:
            st.metric("📊 Registros", f"{st.session_state.data.shape[0]:,}")
    
    with col2:
        if st.session_state.data is not None:
            st.metric("🔢 Features", st.session_state.data.shape[1])
            
    with col3:
        if st.session_state.data is not None:
            st.metric("✅ Status", "Pronto para análise")
    
    # Preview dos dados
    if st.session_state.data is not None:
        st.markdown("### 📋 Preview dos Dados")
        
        # Métricas principais
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            st.metric(
                "💰 Preço Médio", 
                f"${st.session_state.data['price'].mean():.2f}",
                delta=f"±${st.session_state.data['price'].std():.2f}"
            )
        
        with col2:
            st.metric(
                "🏠 Tipos de Quarto", 
                int(st.session_state.data['room_type'].nunique()),
                delta="Variáveis categóricas"
            )
        
        with col3:
            st.metric(
                "🌆 Bairros", 
                int(st.session_state.data['neighbourhood_group'].nunique()),
                delta="Localização geográfica"
            )
        
        with col4:
            st.metric(
                "⭐ Avaliações Médias", 
                f"{st.session_state.data['number_of_reviews'].mean():.0f}",
                delta="Reviews por propriedade"
            )
        
        # Tabela estilizada
        st.dataframe(
            st.session_state.data.head(10), 
            use_container_width=True,
            height=300
        )
        
        # Navegação interativa
        st.markdown("""
            <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); 
                        padding: 3rem; border-radius: 20px; text-align: center; margin-top: 3rem; box-shadow: 0 15px 35px rgba(0,0,0,0.2);">
                <h3 style="color: white; margin: 0 0 2rem 0; font-size: 2rem;">🎯 Fluxo de Análise</h3>
                
                <div style="display: flex; justify-content: space-around; align-items: center; flex-wrap: wrap; gap: 1rem;">
                    <div style="background: rgba(255,255,255,0.2); padding: 1.5rem; border-radius: 15px; min-width: 200px;">
                        <div style="font-size: 3rem; margin-bottom: 1rem;">📊</div>
                        <h4 style="color: white; margin: 0;">1. Exploração</h4>
                        <p style="color: rgba(255,255,255,0.8); margin: 0.5rem 0 0 0; font-size: 0.9rem;">
                            Análise visual dos dados<br>
                            Correlações e distribuições
                        </p>
                    </div>
                    
                    <div style="color: white; font-size: 2rem; align-self: center;">→</div>
                    
                    <div style="background: rgba(255,255,255,0.2); padding: 1.5rem; border-radius: 15px; min-width: 200px;">
                        <div style="font-size: 3rem; margin-bottom: 1rem;">🚀</div>
                        <h4 style="color: white; margin: 0;">2. Treinamento</h4>
                        <p style="color: rgba(255,255,255,0.8); margin: 0.5rem 0 0 0; font-size: 0.9rem;">
                            Execução dos 11 modelos<br>
                            Otimização automática
                        </p>
                    </div>
                    
                    <div style="color: white; font-size: 2rem; align-self: center;">→</div>
                    
                    <div style="background: rgba(255,255,255,0.2); padding: 1.5rem; border-radius: 15px; min-width: 200px;">
                        <div style="font-size: 3rem; margin-bottom: 1rem;">📈</div>
                        <h4 style="color: white; margin: 0;">3. Comparação</h4>
                        <p style="color: rgba(255,255,255,0.8); margin: 0.5rem 0 0 0; font-size: 0.9rem;">
                            Rankings de performance<br>
                            Análise de métricas
                        </p>
                    </div>
                    
                    <div style="color: white; font-size: 2rem; align-self: center;">→</div>
                    
                    <div style="background: rgba(255,255,255,0.2); padding: 1.5rem; border-radius: 15px; min-width: 200px;">
                        <div style="font-size: 3rem; margin-bottom: 1rem;">📋</div>
                        <h4 style="color: white; margin: 0;">4. Relatório</h4>
                        <p style="color: rgba(255,255,255,0.8); margin: 0.5rem 0 0 0; font-size: 0.9rem;">
                            Documentação técnica<br>
                            Resultados detalhados
                        </p>
                    </div>
                </div>
                
                <div style="margin-top: 2rem; padding: 1rem; background: rgba(255,255,255,0.1); border-radius: 10px;">
                    <p style="color: white; margin: 0; font-size: 1.1rem;">
                        🔥 <strong>Use a barra lateral para navegar entre as etapas</strong> 🔥
                    </p>
                </div>
            </div>
        """, unsafe_allow_html=True)
        
    else:
        st.info("👆 Clique no botão acima para carregar o dataset e começar a análise completa!")

if __name__ == "__main__":
    main()