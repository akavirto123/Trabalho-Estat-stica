"""
Script simplificado para criar executável da aplicação.
"""

import os
import subprocess
import sys

def criar_executavel():
    """Cria um executável usando auto-py-to-exe (interface gráfica mais simples)."""
    
    print("Instalando auto-py-to-exe...")
    try:
        subprocess.check_call([sys.executable, "-m", "pip", "install", "auto-py-to-exe"])
        print("✓ auto-py-to-exe instalado com sucesso!")
        print()
        print("Agora execute:")
        print("auto-py-to-exe")
        print()
        print("Na interface que abrir:")
        print("1. Script Location: selecione 'launcher.py'")
        print("2. Onefile: marque 'One File'")
        print("3. Console Window: marque 'Console Based'")
        print("4. Additional Files: adicione as pastas 'pages', 'utils', '.streamlit'")
        print("5. Clique em 'Convert .py to .exe'")
        print()
        print("O executável ficará na pasta 'output'")
        
    except Exception as e:
        print(f"Erro: {e}")
        print()
        print("Tente instalar manualmente:")
        print("pip install auto-py-to-exe")

def criar_batch():
    """Cria um arquivo .bat para Windows que é mais simples."""
    
    batch_content = '''@echo off
echo ========================================
echo   ANALISADOR DE MODELOS DE REGRESSAO
echo ========================================
echo.
echo Iniciando aplicacao...
echo.

REM Verificar se Python esta instalado
python --version >nul 2>&1
if errorlevel 1 (
    echo ERRO: Python nao encontrado!
    echo Por favor, instale Python primeiro.
    pause
    exit /b 1
)

REM Instalar dependencias se necessario
echo Verificando dependencias...
python -c "import streamlit" >nul 2>&1
if errorlevel 1 (
    echo Instalando dependencias... Aguarde...
    pip install streamlit pandas numpy matplotlib seaborn scikit-learn xgboost requests
)

REM Executar aplicacao
echo.
echo Abrindo aplicacao no navegador...
echo Para parar, feche esta janela ou pressione Ctrl+C
echo.
start http://localhost:8501
python -m streamlit run app.py --server.port 8501

pause
'''
    
    with open('ExecutarApp.bat', 'w', encoding='utf-8') as f:
        f.write(batch_content)
    
    print("✓ Arquivo ExecutarApp.bat criado!")
    print()
    print("Agora você pode:")
    print("1. Clicar duas vezes em 'ExecutarApp.bat' para executar")
    print("2. Compartilhar este arquivo .bat junto com os outros arquivos")
    print()
    print("Muito mais simples que criar executável!")

if __name__ == "__main__":
    print("Escolha uma opção:")
    print("1. Criar arquivo .bat (mais simples)")
    print("2. Usar auto-py-to-exe (interface gráfica)")
    
    escolha = input("Digite 1 ou 2: ")
    
    if escolha == "1":
        criar_batch()
    elif escolha == "2":
        criar_executavel()
    else:
        print("Opção inválida!")