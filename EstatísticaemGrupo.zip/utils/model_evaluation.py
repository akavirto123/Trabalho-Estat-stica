import numpy as np
import pandas as pd
import time
from sklearn.metrics import (
    mean_squared_error, 
    mean_absolute_error, 
    r2_score, 
    explained_variance_score,
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    roc_auc_score,
    confusion_matrix
)
import matplotlib.pyplot as plt
import seaborn as sns

def calculate_rmse(y_true, y_pred):
    """
    Calcula o Root Mean Squared Error (RMSE).
    
    Args:
        y_true: Valores reais
        y_pred: Valores previstos
        
    Returns:
        float: RMSE
    """
    return np.sqrt(mean_squared_error(y_true, y_pred))

def evaluate_regression_model(model, X_test, y_test):
    """
    Avalia um modelo de regressão usando várias métricas.
    
    Args:
        model: Modelo treinado
        X_test: Features de teste
        y_test: Target de teste
        
    Returns:
        dict: Métricas de avaliação
    """
    # Fazer previsões
    start_time = time.time()
    y_pred = model.predict(X_test)
    prediction_time = time.time() - start_time
    
    # Calcular métricas
    rmse = calculate_rmse(y_test, y_pred)
    mae = mean_absolute_error(y_test, y_pred)
    r2 = r2_score(y_test, y_pred)
    exp_var = explained_variance_score(y_test, y_pred)
    
    return {
        'y_pred': y_pred,
        'rmse': rmse,
        'mae': mae,
        'r2': r2,
        'explained_variance': exp_var,
        'prediction_time': prediction_time
    }

def evaluate_classification_model(model, X_test, y_test):
    """
    Avalia um modelo de classificação usando várias métricas.
    
    Args:
        model: Modelo treinado
        X_test: Features de teste
        y_test: Target de teste
        
    Returns:
        dict: Métricas de avaliação
    """
    # Fazer previsões
    start_time = time.time()
    y_pred = model.predict(X_test)
    prediction_time = time.time() - start_time
    
    # Probabilidades para ROC AUC (se o modelo tem predict_proba)
    try:
        y_prob = model.predict_proba(X_test)[:, 1]
        has_prob = True
    except:
        y_prob = None
        has_prob = False
    
    # Calcular métricas
    accuracy = accuracy_score(y_test, y_pred)
    precision = precision_score(y_test, y_pred, average='binary')
    recall = recall_score(y_test, y_pred, average='binary')
    f1 = f1_score(y_test, y_pred, average='binary')
    
    result = {
        'y_pred': y_pred,
        'accuracy': accuracy,
        'precision': precision,
        'recall': recall,
        'f1_score': f1,
        'prediction_time': prediction_time
    }
    
    if has_prob:
        result['y_prob'] = y_prob
        result['roc_auc'] = roc_auc_score(y_test, y_prob)
    
    return result

def compare_regression_models(results_dict):
    """
    Compara os resultados de diferentes modelos de regressão.
    
    Args:
        results_dict: Dicionário com resultados de cada modelo
        
    Returns:
        DataFrame: Comparação dos modelos
    """
    models_data = []
    
    for model_name, data in results_dict.items():
        metrics = data['metrics']
        models_data.append({
            'Modelo': model_name,
            'RMSE': metrics['rmse'],
            'MAE': metrics['mae'],
            'R²': metrics['r2'],
            'Variância Explicada': metrics['explained_variance'],
            'Tempo de Treinamento (s)': data['training_time'],
            'Tempo de Predição (s)': metrics['prediction_time']
        })
    
    comparison_df = pd.DataFrame(models_data)
    comparison_df = comparison_df.sort_values('R²', ascending=False)
    
    return comparison_df

def compare_classification_models(results_dict):
    """
    Compara os resultados de diferentes modelos de classificação.
    
    Args:
        results_dict: Dicionário com resultados de cada modelo
        
    Returns:
        DataFrame: Comparação dos modelos
    """
    models_data = []
    
    for model_name, data in results_dict.items():
        metrics = data['metrics']
        model_data = {
            'Modelo': model_name,
            'Acurácia': metrics['accuracy'],
            'Precisão': metrics['precision'],
            'Recall': metrics['recall'],
            'F1-Score': metrics['f1_score'],
            'Tempo de Treinamento (s)': data['training_time'],
            'Tempo de Predição (s)': metrics['prediction_time']
        }
        
        if 'roc_auc' in metrics:
            model_data['ROC AUC'] = metrics['roc_auc']
        
        models_data.append(model_data)
    
    comparison_df = pd.DataFrame(models_data)
    comparison_df = comparison_df.sort_values('Acurácia', ascending=False)
    
    return comparison_df

def plot_regression_scatter(model_name, y_test, y_pred, figsize=(10, 6)):
    """
    Plota gráfico de dispersão entre valores reais e previstos.
    
    Args:
        model_name: Nome do modelo
        y_test: Valores reais
        y_pred: Valores previstos
        figsize: Tamanho da figura
        
    Returns:
        fig: Objeto da figura matplotlib
    """
    fig, ax = plt.subplots(figsize=figsize)
    
    # Limitar pontos para visualização (se houver muitos)
    max_points = 5000
    if len(y_test) > max_points:
        idx = np.random.choice(len(y_test), max_points, replace=False)
        y_test_sample = np.array(y_test.iloc[idx] if hasattr(y_test, 'iloc') else y_test[idx])
        y_pred_sample = np.array(y_pred[idx])
    else:
        y_test_sample = np.array(y_test)
        y_pred_sample = np.array(y_pred)
    
    # Plotar dispersão
    ax.scatter(y_test_sample, y_pred_sample, alpha=0.5)
    
    # Adicionar linha de referência (diagonal)
    max_val = max(np.max(y_test_sample), np.max(y_pred_sample))
    min_val = min(np.min(y_test_sample), np.min(y_pred_sample))
    ax.plot([min_val, max_val], [min_val, max_val], 'r--')
    
    # Configurar gráfico
    ax.set_xlabel('Valores Reais')
    ax.set_ylabel('Valores Previstos')
    ax.set_title(f'Valores Reais vs. Previstos - {model_name}')
    
    return fig

def plot_regression_residuals(model_name, y_test, y_pred, figsize=(10, 6)):
    """
    Plota gráfico de resíduos.
    
    Args:
        model_name: Nome do modelo
        y_test: Valores reais
        y_pred: Valores previstos
        figsize: Tamanho da figura
        
    Returns:
        fig: Objeto da figura matplotlib
    """
    fig, ax = plt.subplots(figsize=figsize)
    
    # Calcular resíduos
    residuals = np.array(y_test) - np.array(y_pred)
    
    # Limitar pontos para visualização (se houver muitos)
    max_points = 5000
    if len(residuals) > max_points:
        idx = np.random.choice(len(residuals), max_points, replace=False)
        y_pred_sample = np.array(y_pred[idx])
        residuals_sample = residuals[idx]
    else:
        y_pred_sample = np.array(y_pred)
        residuals_sample = residuals
    
    # Plotar resíduos
    ax.scatter(y_pred_sample, residuals_sample, alpha=0.5)
    ax.axhline(y=0, color='r', linestyle='--')
    
    # Configurar gráfico
    ax.set_xlabel('Valores Previstos')
    ax.set_ylabel('Resíduos')
    ax.set_title(f'Resíduos - {model_name}')
    
    return fig

def plot_classification_confusion_matrix(model_name, y_test, y_pred, figsize=(8, 6)):
    """
    Plota matriz de confusão para modelos de classificação.
    
    Args:
        model_name: Nome do modelo
        y_test: Valores reais
        y_pred: Valores previstos
        figsize: Tamanho da figura
        
    Returns:
        fig: Objeto da figura matplotlib
    """
    fig, ax = plt.subplots(figsize=figsize)
    
    # Calcular matriz de confusão
    cm = confusion_matrix(y_test, y_pred)
    
    # Plotar matriz de confusão com seaborn
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', ax=ax)
    
    # Configurar gráfico
    ax.set_xlabel('Predito')
    ax.set_ylabel('Real')
    ax.set_title(f'Matriz de Confusão - {model_name}')
    
    return fig
