import numpy as np
import pandas as pd
import time
import streamlit as st
from sklearn.linear_model import LinearRegression, LogisticRegression, Ridge, Lasso, ElasticNet
from sklearn.tree import DecisionTreeRegressor, DecisionTreeClassifier
from sklearn.ensemble import RandomForestRegressor, RandomForestClassifier, GradientBoostingRegressor, GradientBoostingClassifier, AdaBoostRegressor, AdaBoostClassifier
from sklearn.neighbors import KNeighborsRegressor, KNeighborsClassifier
from sklearn.svm import SVR, SVC
from sklearn.neural_network import MLPRegressor, MLPClassifier
import xgboost as xgb
from utils.model_evaluation import evaluate_regression_model, evaluate_classification_model

def get_model_constructor(model_name, is_classification=False):
    """
    Retorna o construtor do modelo com base no nome.
    
    Args:
        model_name: Nome do modelo a ser criado
        is_classification: Se True, retorna versão para classificação, senão para regressão
        
    Returns:
        class: Construtor do modelo
    """
    if is_classification:
        model_constructors = {
            'Regressão Logística': LogisticRegression,
            'Árvore de Decisão': DecisionTreeClassifier,
            'Random Forest': RandomForestClassifier,
            'XGBoost': xgb.XGBClassifier,
            'SVM': SVC,
            'KNN': KNeighborsClassifier,
            'Rede Neural (MLP)': MLPClassifier,
            'Gradient Boosting': GradientBoostingClassifier,
            'AdaBoost': AdaBoostClassifier,
            'Elastic Net': LogisticRegression
        }
    else:
        model_constructors = {
            'Regressão Linear': LinearRegression,
            'Árvore de Decisão': DecisionTreeRegressor,
            'Random Forest': RandomForestRegressor,
            'XGBoost': xgb.XGBRegressor,
            'SVR': SVR,
            'KNN': KNeighborsRegressor,
            'Rede Neural (MLP)': MLPRegressor,
            'Ridge Regression': Ridge,
            'Lasso Regression': Lasso,
            'Gradient Boosting': GradientBoostingRegressor
        }
    
    return model_constructors.get(model_name)

def get_model_params(model_name, is_classification=False):
    """
    Retorna os parâmetros otimizados para cada modelo.
    
    Args:
        model_name: Nome do modelo
        is_classification: Se True, retorna parâmetros para classificação
        
    Returns:
        dict: Parâmetros do modelo
    """
    common_random_state = 42
    
    if is_classification:
        params = {
            'Regressão Logística': {'C': 1.0, 'max_iter': 500, 'random_state': common_random_state, 'solver': 'liblinear'},
            'Árvore de Decisão': {'max_depth': 8, 'min_samples_split': 20, 'random_state': common_random_state},
            'Random Forest': {'n_estimators': 50, 'max_depth': 10, 'n_jobs': -1, 'random_state': common_random_state},
            'XGBoost': {'n_estimators': 50, 'learning_rate': 0.2, 'max_depth': 6, 'random_state': common_random_state},
            'SVM': {'C': 1.0, 'kernel': 'rbf', 'gamma': 'scale'},
            'KNN': {'n_neighbors': 5, 'n_jobs': -1},
            'Rede Neural (MLP)': {'hidden_layer_sizes': (50,), 'max_iter': 300, 'random_state': common_random_state},
            'Gradient Boosting': {'n_estimators': 30, 'learning_rate': 0.2, 'max_depth': 5, 'random_state': common_random_state},
            'AdaBoost': {'n_estimators': 30, 'learning_rate': 0.8, 'random_state': common_random_state},
            'Elastic Net': {'C': 1.0, 'penalty': 'elasticnet', 'solver': 'saga', 'l1_ratio': 0.5, 'max_iter': 500, 'random_state': common_random_state}
        }
    else:
        params = {
            'Regressão Linear': {'n_jobs': -1},
            'Árvore de Decisão': {'max_depth': 5, 'min_samples_split': 50, 'random_state': common_random_state},
            'Random Forest': {'n_estimators': 20, 'max_depth': 8, 'n_jobs': -1, 'random_state': common_random_state},
            'XGBoost': {'n_estimators': 20, 'learning_rate': 0.3, 'max_depth': 4, 'random_state': common_random_state},
            'SVR': {'C': 1.0, 'kernel': 'linear', 'gamma': 'scale'},
            'KNN': {'n_neighbors': 3, 'n_jobs': -1},
            'Rede Neural (MLP)': {'hidden_layer_sizes': (30,), 'max_iter': 200, 'random_state': common_random_state},
            'Ridge Regression': {'alpha': 1.0, 'random_state': common_random_state},
            'Lasso Regression': {'alpha': 0.1, 'random_state': common_random_state, 'max_iter': 500},
            'Gradient Boosting': {'n_estimators': 25, 'learning_rate': 0.2, 'max_depth': 4, 'random_state': common_random_state}
        }
    
    return params.get(model_name, {})

def train_model(model_name, X_train, y_train, is_classification=False, custom_params=None):
    """
    Treina um modelo específico com os dados de treinamento.
    
    Args:
        model_name: Nome do modelo a ser treinado
        X_train: Features de treinamento
        y_train: Target de treinamento
        is_classification: Se True, treina para classificação
        custom_params: Parâmetros personalizados para o modelo
        
    Returns:
        tuple: (modelo treinado, tempo de treinamento)
    """
    model_constructor = get_model_constructor(model_name, is_classification)
    
    if model_constructor is None:
        st.error(f"Modelo {model_name} não encontrado!")
        return None, 0
    
    # Obter parâmetros padrão e atualizar com os personalizados, se fornecidos
    params = get_model_params(model_name, is_classification)
    if custom_params:
        params.update(custom_params)
    
    # Instanciar o modelo com os parâmetros
    model = model_constructor(**params)
    
    # Treinar o modelo e medir o tempo
    start_time = time.time()
    model.fit(X_train, y_train)
    training_time = time.time() - start_time
    
    return model, training_time

def train_all_models(X_train, y_train, X_test, y_test, is_classification=False):
    """
    Treina todos os modelos e avalia seus desempenhos.
    
    Args:
        X_train: Features de treinamento
        y_train: Target de treinamento
        X_test: Features de teste
        y_test: Target de teste
        is_classification: Se True, treina para classificação
        
    Returns:
        dict: Resultados para cada modelo
    """
    if is_classification:
        models_list = [
            'Regressão Logística',
            'Árvore de Decisão',
            'Random Forest',
            'XGBoost',
            'SVM',
            'KNN',
            'Rede Neural (MLP)'
        ]
    else:
        models_list = [
            'Regressão Linear',
            'Árvore de Decisão',
            'Random Forest',
            'XGBoost',
            'SVR',
            'KNN',
            'Rede Neural (MLP)'
        ]
    
    results = {}
    
    for model_name in models_list:
        with st.spinner(f"Treinando {model_name}..."):
            try:
                model, training_time = train_model(model_name, X_train, y_train, is_classification)
                
                if model is not None:
                    if is_classification:
                        metrics = evaluate_classification_model(model, X_test, y_test)
                    else:
                        metrics = evaluate_regression_model(model, X_test, y_test)
                    
                    results[model_name] = {
                        'model': model,
                        'training_time': training_time,
                        'metrics': metrics
                    }
                    
                    st.success(f"{model_name} treinado com sucesso!")
                
            except Exception as e:
                st.error(f"Erro ao treinar {model_name}: {e}")
    
    return results
