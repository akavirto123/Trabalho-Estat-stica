# Pacote utils para a aplicação de análise comparativa de modelos de regressão
