import pandas as pd
import numpy as np
import streamlit as st
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.model_selection import train_test_split
from sklearn.impute import SimpleImputer

def get_numeric_categorical_columns(df):
    """
    Identifica colunas numéricas e categóricas em um DataFrame.
    
    Args:
        df: DataFrame pandas
        
    Returns:
        tuple: (colunas numéricas, colunas categóricas)
    """
    # Identificar colunas numéricas e categóricas
    numeric_cols = df.select_dtypes(include=['int64', 'float64']).columns.tolist()
    categorical_cols = df.select_dtypes(include=['object', 'category', 'bool']).columns.tolist()
    
    return numeric_cols, categorical_cols

def preprocess_airbnb_data(df, target_col='price', test_size=0.2, random_state=42):
    """
    Pré-processa o dataset Airbnb NYC para modelagem.
    
    Args:
        df: DataFrame pandas com os dados brutos
        target_col: Nome da coluna alvo (target)
        test_size: Proporção do conjunto de teste
        random_state: Semente aleatória para reprodutibilidade
        
    Returns:
        tuple: (X_train, X_test, y_train, y_test, preprocessor)
    """
    # Fazer uma cópia para não modificar o original
    df_copy = df.copy()
    
    # Remover colunas que não são úteis para modelagem
    cols_to_drop = ['id', 'name', 'host_name', 'last_review']
    df_copy = df_copy.drop([col for col in cols_to_drop if col in df_copy.columns], axis=1)
    
    # Converter target_col para versão contínua ou binária
    if 'target_type' in st.session_state and st.session_state.target_type == 'binary':
        # Para regressão logística, converter para binário (acima/abaixo da mediana)
        median_price = df_copy[target_col].median()
        df_copy['price_binary'] = (df_copy[target_col] > median_price).astype(int)
        target = df_copy['price_binary']
    else:
        # Para regressão, usar o valor contínuo
        target = df_copy[target_col]
    
    # Remover a coluna target das features
    if 'price_binary' in df_copy.columns:
        df_copy = df_copy.drop(['price_binary', target_col], axis=1)
    else:
        df_copy = df_copy.drop([target_col], axis=1)
    
    # Identificar colunas numéricas e categóricas
    numeric_cols, categorical_cols = get_numeric_categorical_columns(df_copy)
    
    # Definir pré-processadores
    numeric_transformer = Pipeline(steps=[
        ('imputer', SimpleImputer(strategy='median')),
        ('scaler', StandardScaler())
    ])
    
    categorical_transformer = Pipeline(steps=[
        ('imputer', SimpleImputer(strategy='most_frequent')),
        ('onehot', OneHotEncoder(handle_unknown='ignore', sparse_output=False))
    ])
    
    # Unir transformadores em um preprocessador colunar
    preprocessor = ColumnTransformer(
        transformers=[
            ('num', numeric_transformer, numeric_cols),
            ('cat', categorical_transformer, categorical_cols)
        ]
    )
    
    # Dividir os dados em conjuntos de treino e teste
    X_train, X_test, y_train, y_test = train_test_split(
        df_copy, target, test_size=test_size, random_state=random_state
    )
    
    # Ajustar e transformar os dados de treino
    X_train_processed = preprocessor.fit_transform(X_train)
    
    # Transformar os dados de teste
    X_test_processed = preprocessor.transform(X_test)
    
    return X_train_processed, X_test_processed, y_train, y_test, preprocessor, numeric_cols, categorical_cols

def get_feature_names(preprocessor, numeric_cols, categorical_cols):
    """
    Obtém os nomes das features após o pré-processamento.
    
    Args:
        preprocessor: ColumnTransformer ajustado
        numeric_cols: Lista de colunas numéricas
        categorical_cols: Lista de colunas categóricas
        
    Returns:
        list: Nomes das features após o pré-processamento
    """
    # Obter os nomes das features do pipeline de pré-processamento
    cat_features = []
    for i, category in enumerate(categorical_cols):
        ohe = preprocessor.transformers_[1][1].named_steps['onehot']
        cat_features.extend([f"{category}_{cat}" for cat in ohe.categories_[i]])
    
    # Combinar com os nomes das features numéricas
    feature_names = numeric_cols + cat_features
    
    return feature_names

def create_binary_target(df, target_col='price', threshold=None):
    """
    Cria uma versão binária do target para classificação.
    
    Args:
        df: DataFrame pandas
        target_col: Nome da coluna alvo
        threshold: Valor limiar para binarização (se None, usa a mediana)
        
    Returns:
        Series: Coluna target binarizada
    """
    if threshold is None:
        threshold = df[target_col].median()
    
    return (df[target_col] > threshold).astype(int)
