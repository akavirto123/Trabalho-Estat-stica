import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import streamlit as st
from sklearn.decomposition import PCA

def plot_feature_importance(model, feature_names, top_n=20, figsize=(12, 8)):
    """
    Plota a importância das features para modelos que suportam feature_importance_.
    
    Args:
        model: Modelo treinado
        feature_names: Lista com nomes das features
        top_n: Número de features mais importantes a serem exibidas
        figsize: Tamanho da figura
        
    Returns:
        fig: Objeto da figura matplotlib, ou None se o modelo não suportar
    """
    # Verificar se o modelo tem atributo feature_importances_
    if hasattr(model, 'feature_importances_'):
        # Ordenar features por importância
        indices = np.argsort(model.feature_importances_)[::-1]
        
        # Limitar ao top_n
        if len(indices) > top_n:
            indices = indices[:top_n]
        
        # Criar figura
        fig, ax = plt.subplots(figsize=figsize)
        
        # Plotar barras horizontais
        y_pos = np.arange(len(indices))
        ax.barh(y_pos, model.feature_importances_[indices])
        
        # Adicionar nomes das features
        feature_names_limited = [feature_names[i] if i < len(feature_names) else f"Feature {i}" for i in indices]
        ax.set_yticks(y_pos)
        ax.set_yticklabels(feature_names_limited)
        
        # Configurar gráfico
        ax.set_xlabel('Importância')
        ax.set_title('Importância das Features')
        ax.invert_yaxis()  # Para que a feature mais importante apareça no topo
        
        return fig
    else:
        return None

def plot_regression_coefficients(model, feature_names, top_n=20, figsize=(12, 8)):
    """
    Plota os coeficientes de modelos lineares.
    
    Args:
        model: Modelo linear treinado
        feature_names: Lista com nomes das features
        top_n: Número de features com maiores coeficientes (em módulo)
        figsize: Tamanho da figura
        
    Returns:
        fig: Objeto da figura matplotlib, ou None se o modelo não for linear
    """
    # Verificar se o modelo tem atributo coef_
    if hasattr(model, 'coef_'):
        # Garantir que coef_ seja um array unidimensional
        if len(model.coef_.shape) > 1:
            coefs = model.coef_[0]
        else:
            coefs = model.coef_
        
        # Ordenar coeficientes por magnitude
        indices = np.argsort(np.abs(coefs))[::-1]
        
        # Limitar ao top_n
        if len(indices) > top_n:
            indices = indices[:top_n]
        
        # Criar figura
        fig, ax = plt.subplots(figsize=figsize)
        
        # Plotar barras horizontais
        y_pos = np.arange(len(indices))
        ax.barh(y_pos, coefs[indices])
        
        # Adicionar nomes das features
        feature_names_limited = [feature_names[i] if i < len(feature_names) else f"Feature {i}" for i in indices]
        ax.set_yticks(y_pos)
        ax.set_yticklabels(feature_names_limited)
        
        # Configurar gráfico
        ax.set_xlabel('Coeficiente')
        ax.set_title('Coeficientes do Modelo Linear')
        ax.axvline(x=0, color='gray', linestyle='--')
        ax.invert_yaxis()  # Para que o coeficiente com maior magnitude apareça no topo
        
        return fig
    else:
        return None

def plot_distribution_comparison(y_test, y_pred, bins=50, figsize=(12, 6)):
    """
    Plota comparação de distribuições entre valores reais e previstos.
    
    Args:
        y_test: Valores reais
        y_pred: Valores previstos
        bins: Número de bins para o histograma
        figsize: Tamanho da figura
        
    Returns:
        fig: Objeto da figura matplotlib
    """
    fig, ax = plt.subplots(figsize=figsize)
    
    # Limitar valores para visualização mais clara
    y_test_arr = np.array(y_test)
    y_pred_arr = np.array(y_pred)
    
    # Determinar limites para visualização
    min_val = min(np.min(y_test_arr), np.min(y_pred_arr))
    max_val = max(np.max(y_test_arr), np.max(y_pred_arr))
    
    # Criar histogramas
    ax.hist(y_test_arr, bins=bins, alpha=0.5, label='Real', range=(min_val, max_val))
    ax.hist(y_pred_arr, bins=bins, alpha=0.5, label='Previsto', range=(min_val, max_val))
    
    # Configurar gráfico
    ax.set_xlabel('Valor')
    ax.set_ylabel('Frequência')
    ax.set_title('Distribuição de Valores Reais vs. Previstos')
    ax.legend()
    
    return fig

def plot_pca_visualization(X, y, figsize=(10, 8)):
    """
    Plota visualização PCA dos dados.
    
    Args:
        X: Features
        y: Target
        figsize: Tamanho da figura
        
    Returns:
        fig: Objeto da figura matplotlib
    """
    # Aplicar PCA para reduzir para 2 dimensões
    pca = PCA(n_components=2)
    X_pca = pca.fit_transform(X)
    
    # Criar figura
    fig, ax = plt.subplots(figsize=figsize)
    
    # Se y for contínuo, usar scatter com colormap
    if len(np.unique(y)) > 10:  # Considerando como contínuo se houver muitos valores únicos
        scatter = ax.scatter(X_pca[:, 0], X_pca[:, 1], c=y, cmap='viridis', alpha=0.6)
        plt.colorbar(scatter, ax=ax, label='Target')
    else:  # Se for categórico, usar cores diferentes para cada classe
        for i, class_value in enumerate(np.unique(y)):
            mask = y == class_value
            ax.scatter(X_pca[mask, 0], X_pca[mask, 1], label=f'Classe {class_value}', alpha=0.6)
        ax.legend()
    
    # Configurar gráfico
    ax.set_xlabel(f'PC1 ({pca.explained_variance_ratio_[0]:.2%})')
    ax.set_ylabel(f'PC2 ({pca.explained_variance_ratio_[1]:.2%})')
    ax.set_title('Visualização PCA dos Dados')
    
    return fig

def plot_correlation_heatmap(df, figsize=(12, 10)):
    """
    Plota mapa de calor das correlações entre as variáveis numéricas.
    
    Args:
        df: DataFrame pandas
        figsize: Tamanho da figura
        
    Returns:
        fig: Objeto da figura matplotlib
    """
    # Selecionar apenas colunas numéricas
    numeric_df = df.select_dtypes(include=['int64', 'float64'])
    
    # Calcular matriz de correlação
    corr_matrix = numeric_df.corr()
    
    # Criar figura
    fig, ax = plt.subplots(figsize=figsize)
    
    # Plotar heatmap
    sns.heatmap(corr_matrix, annot=True, cmap='coolwarm', fmt=".2f", ax=ax)
    
    # Configurar gráfico
    ax.set_title('Mapa de Correlação entre Variáveis Numéricas')
    
    return fig

def plot_categorical_distribution(df, column, figsize=(12, 6)):
    """
    Plota distribuição de uma variável categórica.
    
    Args:
        df: DataFrame pandas
        column: Nome da coluna categórica
        figsize: Tamanho da figura
        
    Returns:
        fig: Objeto da figura matplotlib
    """
    fig, ax = plt.subplots(figsize=figsize)
    
    # Contar valores e ordenar por frequência
    value_counts = df[column].value_counts()
    
    # Limitar número de categorias para visualização
    max_categories = 15
    if len(value_counts) > max_categories:
        other_count = value_counts[max_categories:].sum()
        value_counts = value_counts[:max_categories]
        value_counts['Outros'] = other_count
    
    # Plotar barras
    value_counts.plot(kind='bar', ax=ax)
    
    # Configurar gráfico
    ax.set_title(f'Distribuição da Variável {column}')
    ax.set_ylabel('Contagem')
    ax.set_xlabel(column)
    plt.xticks(rotation=45, ha='right')
    
    return fig

def plot_numeric_by_categorical(df, numeric_col, categorical_col, figsize=(12, 6)):
    """
    Plota boxplot de variável numérica agrupada por variável categórica.
    
    Args:
        df: DataFrame pandas
        numeric_col: Nome da coluna numérica
        categorical_col: Nome da coluna categórica
        figsize: Tamanho da figura
        
    Returns:
        fig: Objeto da figura matplotlib
    """
    fig, ax = plt.subplots(figsize=figsize)
    
    # Limitar número de categorias para visualização
    max_categories = 10
    value_counts = df[categorical_col].value_counts()
    
    if len(value_counts) > max_categories:
        top_categories = value_counts.index[:max_categories]
        df_filtered = df[df[categorical_col].isin(top_categories)]
    else:
        df_filtered = df
    
    # Plotar boxplot
    sns.boxplot(x=categorical_col, y=numeric_col, data=df_filtered, ax=ax)
    
    # Configurar gráfico
    ax.set_title(f'{numeric_col} por {categorical_col}')
    ax.set_xlabel(categorical_col)
    ax.set_ylabel(numeric_col)
    plt.xticks(rotation=45, ha='right')
    
    return fig

def plot_learning_curves(model_results, figsize=(10, 6)):
    """
    Plota curvas de aprendizado comparando múltiplos modelos.
    
    Args:
        model_results: Dicionário com resultados dos modelos
        figsize: Tamanho da figura
        
    Returns:
        fig: Objeto da figura matplotlib
    """
    metric_name = 'R²'  # Métrica para comparação
    
    fig, ax = plt.subplots(figsize=figsize)
    
    for model_name, result in model_results.items():
        if 'learning_curve' in result:
            train_sizes = result['learning_curve']['train_sizes']
            train_scores = result['learning_curve']['train_scores']
            test_scores = result['learning_curve']['test_scores']
            
            # Plotar médias de treino e teste
            ax.plot(train_sizes, np.mean(train_scores, axis=1), 'o-', label=f'{model_name} (treino)')
            ax.plot(train_sizes, np.mean(test_scores, axis=1), 'o--', label=f'{model_name} (teste)')
    
    # Configurar gráfico
    ax.set_xlabel('Tamanho do Conjunto de Treino')
    ax.set_ylabel(metric_name)
    ax.set_title('Curvas de Aprendizado')
    ax.legend()
    ax.grid(True)
    
    return fig
