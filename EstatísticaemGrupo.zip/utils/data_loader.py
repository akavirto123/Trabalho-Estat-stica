import pandas as pd
import streamlit as st
from io import BytesIO
import requests
import os

@st.cache_data
def load_data():
    """
    Carrega o dataset NYC Airbnb Open Data de fontes públicas.
    """
    # URLs confiáveis para o dataset real do NYC Airbnb
    urls = [
        "https://raw.githubusercontent.com/erikbruin/open-data-sites/master/NYC_Airbnb/AB_NYC_2019.csv",
        "https://storage.googleapis.com/kagglesdsdata/datasets/1322/2641/AB_NYC_2019.csv?X-Goog-Algorithm=GOOG4-RSA-SHA256",
        "https://data.cityofnewyork.us/api/views/dss4-da7a/rows.csv?accessType=DOWNLOAD"
    ]
    
    for i, url in enumerate(urls):
        try:
            st.info(f"Tentando carregar dataset do NYC Airbnb (fonte {i+1}/{len(urls)})...")
            response = requests.get(url, timeout=30)
            if response.status_code == 200:
                df = pd.read_csv(BytesIO(response.content))
                if len(df) > 10000:  # Verificar se tem dados suficientes
                    st.success(f"Dataset carregado com sucesso! {len(df):,} registros encontrados.")
                    return df
        except Exception as e:
            st.warning(f"Fonte {i+1} falhou: {str(e)[:100]}...")
            continue
    
    # Se falhar, usar dados do arquivo local se existir
    if os.path.exists("AB_NYC_2019.csv"):
        return pd.read_csv("AB_NYC_2019.csv")
    
    # Último recurso: criar dataset baseado em estrutura real mas com dados gerados
    st.warning("Criando dataset de demonstração baseado na estrutura real do NYC Airbnb...")
    
    import numpy as np
    np.random.seed(42)
    n_samples = 15000  # Tamanho otimizado para treinamento rápido mas ainda representativo
    
    # Dados baseados na distribuição real do NYC Airbnb com tipos compatíveis
    data = {
        'id': np.arange(1, n_samples + 1, dtype='int32'),
        'name': [f'NYC Listing {i}' for i in range(1, n_samples + 1)],
        'host_id': np.random.randint(1, 37457, n_samples, dtype='int32'),
        'host_name': [f'Host_{i}' for i in np.random.randint(1, 11453, n_samples)],
        'neighbourhood_group': np.random.choice(['Manhattan', 'Brooklyn', 'Queens', 'Bronx', 'Staten Island'], 
                                              n_samples, p=[0.44, 0.41, 0.10, 0.03, 0.02]),
        'neighbourhood': np.random.choice([f'Area_{i}' for i in range(1, 222)], n_samples),
        'latitude': np.random.uniform(40.4774, 40.9176, n_samples).astype('float32'),
        'longitude': np.random.uniform(-74.2591, -73.7004, n_samples).astype('float32'),
        'room_type': np.random.choice(['Entire home/apt', 'Private room', 'Shared room'], 
                                    n_samples, p=[0.52, 0.45, 0.03]),
        'price': np.clip(np.random.lognormal(4.5, 1.2, n_samples), 0, 10000).astype('int32'),
        'minimum_nights': np.random.choice([1, 2, 3, 4, 5, 7, 30], n_samples).astype('int32'),
        'number_of_reviews': np.random.negative_binomial(5, 0.3, n_samples).astype('int32'),
        'last_review': pd.date_range(start='2011-01-01', end='2019-07-08', periods=n_samples).astype(str),
        'reviews_per_month': np.random.exponential(1.5, n_samples).astype('float32'),
        'calculated_host_listings_count': np.random.geometric(0.7, n_samples).astype('int32'),
        'availability_365': np.random.choice(range(0, 366), n_samples).astype('int32')
    }
    
    df = pd.DataFrame(data)
    
    # Solução definitiva para compatibilidade com Arrow/Streamlit
    # Forçar conversão para tipos básicos do Python
    for col in df.columns:
        if df[col].dtype.name.startswith('int'):
            df[col] = df[col].astype('int64').astype('object').astype('int64')
        elif df[col].dtype.name.startswith('float'):
            df[col] = df[col].astype('float64').astype('object').astype('float64')
        elif df[col].dtype == 'object':
            df[col] = df[col].astype('str')
    
    # Reset do index para evitar problemas
    df = df.reset_index(drop=True)
    
    return df
