#!/usr/bin/env python3
"""
Script para executar a aplicação de análise comparativa de modelos de regressão.
"""

import sys
import subprocess
import os

def check_dependencies():
    """Verifica se as dependências estão instaladas."""
    required_packages = [
        'streamlit',
        'pandas',
        'numpy',
        'matplotlib',
        'seaborn',
        'scikit-learn',
        'xgboost'
    ]
    
    missing_packages = []
    
    for package in required_packages:
        try:
            __import__(package)
        except ImportError:
            missing_packages.append(package)
    
    if missing_packages:
        print(f"Pacotes em falta: {', '.join(missing_packages)}")
        print("Para instalar, execute:")
        print(f"pip install {' '.join(missing_packages)}")
        return False
    
    return True

def run_app():
    """Executa a aplicação Streamlit."""
    if not check_dependencies():
        print("Por favor, instale as dependências primeiro.")
        return
    
    print("Iniciando a aplicação...")
    print("A aplicação será aberta em: http://localhost:8501")
    print("Para parar a aplicação, pressione Ctrl+C")
    
    try:
        subprocess.run([
            sys.executable, "-m", "streamlit", "run", "app.py",
            "--server.port", "8501",
            "--server.address", "0.0.0.0"
        ])
    except KeyboardInterrupt:
        print("\nAplicação interrompida pelo usuário.")
    except Exception as e:
        print(f"Erro ao executar a aplicação: {e}")

if __name__ == "__main__":
    run_app()