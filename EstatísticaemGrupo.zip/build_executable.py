"""
Script para criar um executável da aplicação de análise comparativa de modelos.
"""

import os
import subprocess
import sys

def create_executable():
    """Cria um executável da aplicação usando PyInstaller."""
    
    # Verificar se PyInstaller está instalado
    try:
        import PyInstaller
    except ImportError:
        print("Instalando PyInstaller...")
        subprocess.check_call([sys.executable, "-m", "pip", "install", "pyinstaller"])
    
    # Criar o spec file personalizado
    spec_content = """
# -*- mode: python ; coding: utf-8 -*-

block_cipher = None

a = Analysis(
    ['app.py'],
    pathex=[],
    binaries=[],
    datas=[
        ('pages', 'pages'),
        ('utils', 'utils'),
        ('.streamlit', '.streamlit'),
    ],
    hiddenimports=[
        'streamlit',
        'pandas',
        'numpy',
        'matplotlib',
        'seaborn',
        'scikit-learn',
        'xgboost',
        'sklearn.ensemble._forest',
        'sklearn.tree._tree',
        'sklearn.neighbors._base',
        'sklearn.neural_network._multilayer_perceptron',
        'sklearn.svm._classes',
        'streamlit.web.cli',
    ],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    win_no_prefer_redirects=False,
    win_private_assemblies=False,
    cipher=block_cipher,
    noarchive=False,
)

pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.zipfiles,
    a.datas,
    [],
    name='AnalisadorModelos',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    upx_exclude=[],
    runtime_tmpdir=None,
    console=True,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
)
"""
    
    # Salvar o spec file
    with open('app.spec', 'w') as f:
        f.write(spec_content)
    
    print("Criando executável... Isso pode levar alguns minutos.")
    
    try:
        # Executar PyInstaller
        subprocess.check_call([
            sys.executable, "-m", "PyInstaller",
            "--onefile",
            "--name=AnalisadorModelos",
            "--add-data=pages:pages",
            "--add-data=utils:utils",
            "--add-data=.streamlit:.streamlit",
            "--hidden-import=streamlit",
            "--hidden-import=pandas",
            "--hidden-import=numpy",
            "--hidden-import=matplotlib",
            "--hidden-import=seaborn",
            "--hidden-import=scikit-learn",
            "--hidden-import=xgboost",
            "app.py"
        ])
        
        print("\n✓ Executável criado com sucesso!")
        print("O arquivo está em: dist/AnalisadorModelos.exe")
        print("\nPara usar:")
        print("1. Copie o arquivo AnalisadorModelos.exe para onde quiser")
        print("2. Execute o arquivo")
        print("3. Abra http://localhost:8501 no navegador")
        
    except subprocess.CalledProcessError as e:
        print(f"Erro ao criar executável: {e}")
        return False
    
    return True

if __name__ == "__main__":
    create_executable()