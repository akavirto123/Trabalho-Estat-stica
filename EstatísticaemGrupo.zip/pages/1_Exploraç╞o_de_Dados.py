import streamlit as st
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from utils.visualization import (
    plot_correlation_heatmap,
    plot_categorical_distribution,
    plot_numeric_by_categorical,
    plot_pca_visualization
)
from utils.preprocess import get_numeric_categorical_columns

# Configuração da página
st.set_page_config(
    page_title="Exploração de Dados - Análise Comparativa de Modelos",
    page_icon="📊",
    layout="wide"
)

# Título da página
st.title("Exploração de Dados")
st.write("Nesta página, você pode explorar os dados antes de treinar os modelos.")

# Verificar se os dados foram carregados
if 'data' not in st.session_state or st.session_state.data is None:
    st.warning("Por favor, carregue os dados na página inicial antes de continuar.")
    st.stop()

# Exibir informações básicas do dataset
st.header("Informações Básicas do Dataset")

col1, col2 = st.columns(2)
with col1:
    st.write(f"**Número de registros:** {st.session_state.data.shape[0]:,}")
    st.write(f"**Número de atributos:** {st.session_state.data.shape[1]}")

with col2:
    st.write("**Tipos de dados:**")
    st.write(st.session_state.data.dtypes.value_counts())

# Exibir amostra dos dados
st.header("Amostra dos Dados")
sample_size = st.slider("Número de registros para amostra", 5, 100, 10)
st.dataframe(st.session_state.data.sample(sample_size))

# Mostrar estatísticas descritivas
st.header("Estatísticas Descritivas")
with st.expander("Ver estatísticas descritivas"):
    # Selecionar apenas colunas numéricas para as estatísticas
    numeric_cols = st.session_state.data.select_dtypes(include=['int64', 'float64']).columns
    st.dataframe(st.session_state.data[numeric_cols].describe())

# Verificar valores faltantes
st.header("Valores Faltantes")
missing_data = st.session_state.data.isnull().sum()
missing_data = missing_data[missing_data > 0].sort_values(ascending=False)

if len(missing_data) > 0:
    col1, col2 = st.columns(2)
    with col1:
        st.write("Colunas com valores faltantes:")
        st.dataframe(pd.DataFrame({
            'Coluna': missing_data.index,
            'Valores Faltantes': missing_data.values,
            'Porcentagem': (missing_data.values / len(st.session_state.data) * 100).round(2)
        }))
    
    with col2:
        fig, ax = plt.subplots(figsize=(10, 6))
        missing_data.plot(kind='bar', ax=ax)
        ax.set_title('Valores Faltantes por Coluna')
        ax.set_ylabel('Contagem')
        plt.xticks(rotation=45, ha='right')
        st.pyplot(fig)
else:
    st.success("Não há valores faltantes no dataset!")

# Análise univariada
st.header("Análise Univariada")

# Identificar colunas numéricas e categóricas
numeric_cols, categorical_cols = get_numeric_categorical_columns(st.session_state.data)

# Análise de variáveis numéricas
st.subheader("Variáveis Numéricas")
numeric_col = st.selectbox("Selecione uma variável numérica para análise:", numeric_cols)

col1, col2 = st.columns(2)
with col1:
    fig, ax = plt.subplots(figsize=(10, 6))
    sns.histplot(st.session_state.data[numeric_col].dropna(), kde=True, ax=ax)
    ax.set_title(f'Distribuição de {numeric_col}')
    st.pyplot(fig)

with col2:
    fig, ax = plt.subplots(figsize=(10, 6))
    sns.boxplot(y=st.session_state.data[numeric_col].dropna(), ax=ax)
    ax.set_title(f'Boxplot de {numeric_col}')
    st.pyplot(fig)

# Análise de variáveis categóricas
if len(categorical_cols) > 0:
    st.subheader("Variáveis Categóricas")
    categorical_col = st.selectbox("Selecione uma variável categórica para análise:", categorical_cols)
    
    fig = plot_categorical_distribution(st.session_state.data, categorical_col)
    st.pyplot(fig)

# Análise bivariada
st.header("Análise Bivariada")

# Correlação entre variáveis numéricas
st.subheader("Correlação entre Variáveis Numéricas")
fig = plot_correlation_heatmap(st.session_state.data[numeric_cols])
st.pyplot(fig)

# Relação entre variáveis numéricas e categóricas
if len(categorical_cols) > 0:
    st.subheader("Relação entre Variáveis Numéricas e Categóricas")
    
    col1, col2 = st.columns(2)
    with col1:
        num_col = st.selectbox("Selecione uma variável numérica:", numeric_cols)
    
    with col2:
        cat_col = st.selectbox("Selecione uma variável categórica:", categorical_cols, key='cat_col_bivariate')
    
    fig = plot_numeric_by_categorical(st.session_state.data, num_col, cat_col)
    st.pyplot(fig)

# Relação entre variáveis numéricas
st.subheader("Relação entre Variáveis Numéricas")
col1, col2 = st.columns(2)
with col1:
    x_col = st.selectbox("Selecione a variável para o eixo X:", numeric_cols)

with col2:
    y_col = st.selectbox("Selecione a variável para o eixo Y:", [col for col in numeric_cols if col != x_col])

fig, ax = plt.subplots(figsize=(10, 6))
sns.scatterplot(x=x_col, y=y_col, data=st.session_state.data, alpha=0.5, ax=ax)
ax.set_title(f'Relação entre {x_col} e {y_col}')
st.pyplot(fig)

# Visualização com PCA
st.header("Visualização com PCA")
st.write("A visualização PCA (Análise de Componentes Principais) pode ajudar a entender a estrutura dos dados em um espaço dimensional reduzido.")

if st.button("Gerar Visualização PCA"):
    with st.spinner("Gerando visualização PCA..."):
        # Selecionar apenas colunas numéricas para PCA
        numeric_data = st.session_state.data[numeric_cols].dropna()
        
        if 'price' in numeric_data.columns:
            X = numeric_data.drop('price', axis=1)
            y = numeric_data['price']
            
            fig = plot_pca_visualization(X, y)
            st.pyplot(fig)
        else:
            st.error("Coluna 'price' não encontrada para usar como target na visualização PCA.")

# Análise geoespacial (específica para dataset Airbnb)
if 'latitude' in st.session_state.data.columns and 'longitude' in st.session_state.data.columns:
    st.header("Análise Geoespacial")
    st.write("Visualização da distribuição geográfica das listagens do Airbnb em Nova York.")
    
    # Limitar pontos para visualização
    max_points = 5000
    if len(st.session_state.data) > max_points:
        geo_sample = st.session_state.data.sample(max_points)
    else:
        geo_sample = st.session_state.data
    
    # Definir variável para coloração
    color_var = st.selectbox("Variável para coloração:", 
                           [col for col in numeric_cols if col not in ['latitude', 'longitude']])
    
    fig, ax = plt.subplots(figsize=(12, 10))
    scatter = ax.scatter(
        geo_sample['longitude'], 
        geo_sample['latitude'],
        c=geo_sample[color_var] if color_var in geo_sample else None,
        alpha=0.6,
        cmap='viridis',
        s=20
    )
    
    plt.colorbar(scatter, ax=ax, label=color_var)
    ax.set_title(f'Distribuição Geográfica (colorido por {color_var})')
    ax.set_xlabel('Longitude')
    ax.set_ylabel('Latitude')
    st.pyplot(fig)

# Mostrar insights e conclusões
st.header("Insights e Conclusões")
st.write("""
## Principais Insights da Exploração de Dados

1. **Distribuição de Preços**: Os preços das acomodações no Airbnb em Nova York têm uma distribuição assimétrica à direita, 
   com muitos valores mais baixos e alguns valores extremamente altos, indicando uma grande variabilidade de opções.

2. **Fatores Geográficos**: A localização é um fator crítico, com Manhattan apresentando preços médios mais elevados 
   em comparação com os outros bairros.

3. **Tipo de Propriedade**: O tipo de acomodação (apartamento inteiro, quarto privado, quarto compartilhado) 
   tem grande influência no preço, com apartamentos inteiros geralmente tendo preços mais altos.

4. **Disponibilidade e Sazonalidade**: Há uma relação entre a disponibilidade ao longo do ano e o preço, 
   sugerindo possíveis efeitos sazonais no mercado.

5. **Correlações**: Variáveis como número de avaliações, disponibilidade e número de listagens do mesmo host 
   apresentam correlações interessantes com o preço.

Estes insights serão fundamentais para entender os resultados dos modelos de predição e para interpretar 
quais fatores são mais importantes para determinar o preço de uma acomodação no Airbnb em Nova York.
""")
