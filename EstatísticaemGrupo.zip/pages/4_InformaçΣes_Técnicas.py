import streamlit as st
import pandas as pd
import numpy as np

# Configuração da página
st.set_page_config(
    page_title="Informações Técnicas - Análise Comparativa",
    page_icon="🔬",
    layout="wide"
)

# Título da página
st.title("Informações Técnicas Detalhadas")

# Seção de créditos expandida
st.header("👥 Créditos do Projeto")
col1, col2 = st.columns(2)

with col1:
    st.markdown("""
    ### Desenvolvido por:
    - **Vitor Correia**
    - **Lívia Collete**
    - **Filipe Carreira**
    
    ### Contexto Acadêmico:
    - **Projeto:** Análise Comparativa de Modelos de ML
    - **Objetivo:** Comparar 11 modelos de ML aplicados ao NYC Airbnb
    - **Implementação:** 2 modelos obrigatórios + 9 adicionais
    """)

with col2:
    st.markdown("""
    ### Tecnologias Utilizadas:
    - **Python 3.11+** - Linguagem principal
    - **Streamlit** - Interface web interativa
    - **Scikit-learn** - Algoritmos de Machine Learning
    - **XGBoost** - Gradient Boosting otimizado
    - **Pandas & NumPy** - Manipulação de dados
    - **Matplotlib & Seaborn** - Visualizações
    """)

# Arquitetura do sistema
st.header("🏗️ Arquitetura do Sistema")

st.markdown("""
### Estrutura Modular

O sistema foi desenvolvido com arquitetura modular para facilitar manutenção e extensibilidade:

```
projeto/
├── app.py                      # Página principal e configuração
├── pages/                      # Páginas da aplicação
│   ├── 1_Exploração_de_Dados.py    # EDA e visualizações
│   ├── 2_Treinamento_de_Modelos.py # Interface de treinamento
│   ├── 3_Comparação_de_Resultados.py # Análise comparativa
│   └── 4_Informações_Técnicas.py   # Esta página
├── utils/                      # Módulos de utilidade
│   ├── data_loader.py              # Carregamento de dados
│   ├── preprocess.py               # Pré-processamento
│   ├── model_trainer.py            # Treinamento de modelos
│   ├── model_evaluation.py         # Avaliação e métricas
│   └── visualization.py            # Funções de visualização
└── .streamlit/
    └── config.toml                 # Configurações do Streamlit
```
""")

# Detalhes dos modelos
st.header("🤖 Detalhes dos Modelos Implementados")

tab1, tab2, tab3 = st.tabs(["Modelos Obrigatórios", "Modelos Adicionais", "Parâmetros Otimizados"])

with tab1:
    st.subheader("Modelos Obrigatórios")
    
    st.markdown("""
    ### 1. Regressão Linear
    **Algoritmo:** Ordinary Least Squares (OLS)
    ```python
    from sklearn.linear_model import LinearRegression
    modelo = LinearRegression(n_jobs=-1)
    ```
    
    **Funcionamento:**
    - Minimiza a soma dos quadrados dos resíduos
    - Encontra a melhor linha reta que se ajusta aos dados
    - Assume relação linear entre features e target
    
    **Vantagens:** Rápido, interpretável, base matemática sólida
    **Desvantagens:** Limitado a relações lineares, sensível a outliers
    
    ---
    
    ### 2. Regressão Logística (para classificação)
    **Algoritmo:** Maximum Likelihood Estimation
    ```python
    from sklearn.linear_model import LogisticRegression
    modelo = LogisticRegression(C=1.0, max_iter=500, solver='liblinear')
    ```
    
    **Funcionamento:**
    - Usa função sigmoid para mapear qualquer valor real para (0,1)
    - Modela a probabilidade de pertencer a uma classe
    - Otimização através de gradient descent
    
    **Vantagens:** Fornece probabilidades, robusto, interpretável
    **Desvantagens:** Assume fronteiras de decisão lineares
    """)

with tab2:
    st.subheader("Modelos Adicionais")
    
    st.markdown("""
    ### 3. Árvore de Decisão
    **Algoritmo:** CART (Classification and Regression Trees)
    ```python
    from sklearn.tree import DecisionTreeRegressor
    modelo = DecisionTreeRegressor(max_depth=5, min_samples_split=50)
    ```
    
    **Funcionamento:**
    - Divisões recursivas baseadas em critério de pureza (MSE para regressão)
    - Cada nó representa uma regra de decisão
    - Folhas contêm predições finais
    
    ---
    
    ### 4. Random Forest
    **Algoritmo:** Bootstrap Aggregating (Bagging) + Random Subspace
    ```python
    from sklearn.ensemble import RandomForestRegressor
    modelo = RandomForestRegressor(n_estimators=20, max_depth=8, n_jobs=-1)
    ```
    
    **Funcionamento:**
    - Treina múltiplas árvores em subsets aleatórios dos dados
    - Cada árvore usa subset aleatório de features
    - Predição final = média das predições individuais
    
    ---
    
    ### 5. XGBoost
    **Algoritmo:** Extreme Gradient Boosting
    ```python
    import xgboost as xgb
    modelo = xgb.XGBRegressor(n_estimators=20, learning_rate=0.3, max_depth=4)
    ```
    
    **Funcionamento:**
    - Boosting: modelos sequenciais que corrigem erros anteriores
    - Regularização L1 e L2 para evitar overfitting
    - Otimização de segunda ordem (Newton-Raphson)
    
    ---
    
    ### 6. Support Vector Regression (SVR)
    **Algoritmo:** Support Vector Machines adaptado para regressão
    ```python
    from sklearn.svm import SVR
    modelo = SVR(C=1.0, kernel='linear', gamma='scale')
    ```
    
    **Funcionamento:**
    - Encontra hiperplano que maximiza margem de tolerância (ε-tube)
    - Kernel trick para transformações não-lineares
    - Otimização quadrática convexa
    
    ---
    
    ### 7. K-Nearest Neighbors (KNN)
    **Algoritmo:** Instance-based learning
    ```python
    from sklearn.neighbors import KNeighborsRegressor
    modelo = KNeighborsRegressor(n_neighbors=3, n_jobs=-1)
    ```
    
    **Funcionamento:**
    - Encontra k amostras mais próximas no espaço de features
    - Predição = média dos valores dos k vizinhos
    - Usa distância euclidiana por padrão
    
    ---
    
    ### 8. Rede Neural (MLP)
    **Algoritmo:** Multi-Layer Perceptron com Backpropagation
    ```python
    from sklearn.neural_network import MLPRegressor
    modelo = MLPRegressor(hidden_layer_sizes=(30,), max_iter=200)
    ```
    
    **Funcionamento:**
    - Rede feedforward com camadas ocultas
    - Função de ativação ReLU nas camadas ocultas
    - Otimização via ADAM optimizer
    - Backpropagation para ajustar pesos
    """)

with tab3:
    st.subheader("Parâmetros Otimizados para Performance")
    
    st.markdown("""
    ### Otimizações Implementadas
    
    Os parâmetros foram ajustados para equilibrar **precisão** e **velocidade de treinamento**:
    
    | Modelo | Parâmetros Originais | Parâmetros Otimizados | Justificativa |
    |--------|---------------------|----------------------|---------------|
    | Random Forest | n_estimators=100 | n_estimators=20 | Reduz tempo sem perda significativa |
    | XGBoost | n_estimators=100 | n_estimators=20 | 20 árvores suficientes para convergência |
    | Decision Tree | max_depth=10 | max_depth=5 | Previne overfitting |
    | SVR | kernel='rbf' | kernel='linear' | Linear é mais rápido para este dataset |
    | MLP | hidden_layer_sizes=(100,) | hidden_layer_sizes=(30,) | Menor complexidade |
    | MLP | max_iter=1000 | max_iter=200 | Convergência mais rápida |
    
    ### Paralelização
    Todos os modelos compatíveis usam `n_jobs=-1` para utilizar todos os cores do processador.
    """)

# Processo de treinamento
st.header("⚙️ Processo de Treinamento")

st.markdown("""
### Pipeline de Treinamento

1. **Carregamento de Dados**
   - Tentativa de acesso a fontes públicas do dataset NYC Airbnb
   - Fallback para dados sintéticos baseados na estrutura real
   - Validação de integridade e tamanho mínimo

2. **Pré-processamento**
   ```python
   # Divisão treino/teste
   X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2)
   
   # Pipeline de transformação
   numeric_transformer = Pipeline([
       ('imputer', SimpleImputer(strategy='median')),
       ('scaler', StandardScaler())
   ])
   
   categorical_transformer = Pipeline([
       ('imputer', SimpleImputer(strategy='most_frequent')),
       ('onehot', OneHotEncoder(handle_unknown='ignore'))
   ])
   ```

3. **Treinamento Sequencial**
   - Cada modelo é treinado independentemente
   - Medição de tempo de treinamento e predição
   - Tratamento de exceções para modelos que falham

4. **Avaliação Automática**
   - Cálculo de métricas padronizadas
   - Geração de visualizações comparativas
   - Armazenamento de resultados em session state
""")

# Métricas
st.header("📊 Métricas de Avaliação Detalhadas")

col1, col2 = st.columns(2)

with col1:
    st.markdown("""
    ### RMSE (Root Mean Squared Error)
    ```python
    import numpy as np
    from sklearn.metrics import mean_squared_error
    
    rmse = np.sqrt(mean_squared_error(y_true, y_pred))
    ```
    
    **Interpretação:**
    - Mesma unidade da variável target (preço em US$)
    - Penaliza erros grandes mais que erros pequenos
    - Valores menores = melhor performance
    - Sensível a outliers
    
    **Fórmula:** √(Σ(y_true - y_pred)² / n)
    """)

with col2:
    st.markdown("""
    ### R² (Coeficiente de Determinação)
    ```python
    from sklearn.metrics import r2_score
    
    r2 = r2_score(y_true, y_pred)
    ```
    
    **Interpretação:**
    - Varia de -∞ a 1
    - 1 = predição perfeita
    - 0 = modelo não melhor que média
    - < 0 = modelo pior que predizer sempre a média
    
    **Fórmula:** 1 - (SS_res / SS_tot)
    """)

st.markdown("""
### Explained Variance Score
```python
from sklearn.metrics import explained_variance_score

evs = explained_variance_score(y_true, y_pred)
```

**Interpretação:**
- Similar ao R², mas não penaliza bias sistemático
- Mede apenas a variância explicada
- Útil quando há bias constante nas predições
- Varia de -∞ a 1

**Fórmula:** 1 - Var(y_true - y_pred) / Var(y_true)
""")

# Considerações técnicas
st.header("⚠️ Considerações Técnicas e Limitações")

st.markdown("""
### Limitações Atuais

1. **Dataset Sintético**
   - Por limitações de acesso, usamos dados sintéticos baseados na estrutura real
   - Preserva características estatísticas do dataset original
   - Ideal para demonstração de metodologia

2. **Parâmetros Simplificados**
   - Otimizados para velocidade em detrimento de precisão máxima
   - Adequados para fins educacionais e demonstração
   - Em produção, seria necessário tuning mais extensivo

3. **Validação Cruzada**
   - Implementação atual usa holdout simples (80/20)
   - Para robustez maior, k-fold cross-validation seria recomendado

### Melhorias Futuras

1. **Acesso a Dados Reais**
   - Integração com APIs do Kaggle para dados autênticos
   - Suporte a múltiplos datasets

2. **Hyperparameter Tuning**
   - Grid Search ou Random Search automático
   - Otimização bayesiana para melhores parâmetros

3. **Modelos Avançados**
   - LightGBM, CatBoost para gradient boosting
   - Redes neurais profundas (Deep Learning)
   - Ensemble methods personalizados

### Reprodutibilidade

Todos os experimentos usam `random_state=42` para garantir resultados reproduzíveis.
""")

# Conclusão
st.header("🎯 Conclusão")

st.markdown("""
Esta aplicação demonstra uma pipeline completa de Machine Learning para análise comparativa de modelos,
desde o carregamento de dados até a avaliação final. O código está estruturado de forma modular e 
extensível, seguindo boas práticas de desenvolvimento.

**Principais Contribuições:**
- Interface interativa para exploração de dados
- Comparação sistemática de 8 algoritmos diferentes
- Visualizações detalhadas de performance
- Código documentado e reutilizável

**Aplicabilidade:**
- Educação em Machine Learning
- Prototipagem rápida de modelos
- Análise exploratória de algoritmos
- Base para projetos mais complexos
""")

# Rodapé
st.markdown("---")
st.markdown("**Desenvolvido por Vitor Correia e Lívia Collete** | Projeto Acadêmico 2024")