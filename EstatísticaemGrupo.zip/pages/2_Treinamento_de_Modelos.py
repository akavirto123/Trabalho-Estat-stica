import streamlit as st
import pandas as pd
import numpy as np
import time
import matplotlib.pyplot as plt
import seaborn as sns
from utils.preprocess import preprocess_airbnb_data, get_feature_names
from utils.model_trainer import train_all_models
from sklearn.model_selection import train_test_split

# Configuração da página
st.set_page_config(
    page_title="Treinamento de Modelos - Análise Comparativa",
    page_icon="🧪",
    layout="wide"
)

# Título da página
st.title("Treinamento de Modelos")
st.write("Nesta página, você pode treinar e ajustar diferentes modelos para o problema.")

# Verificar se os dados foram carregados
if 'data' not in st.session_state or st.session_state.data is None:
    st.warning("Por favor, carregue os dados na página inicial antes de continuar.")
    st.stop()

# Parâmetros para pré-processamento e divisão dos dados
st.header("Configuração do Pré-processamento")

col1, col2 = st.columns(2)
with col1:
    target_type = st.radio(
        "Tipo de Target:",
        ["Contínuo (Regressão)", "Binário (Classificação)"],
        index=0
    )
    
    st.session_state.target_type = 'continuous' if target_type == "Contínuo (Regressão)" else 'binary'

with col2:
    test_size = st.slider("Tamanho do Conjunto de Teste (%)", 10, 40, 20) / 100
    random_state = st.slider("Seed Aleatória", 1, 100, 42)

# Parâmetros para filtragem de dados
st.subheader("Filtragem de Dados (Opcional)")

col1, col2 = st.columns(2)
with col1:
    use_price_filter = st.checkbox("Filtrar por Faixa de Preço", value=True)
    min_price, max_price = (0, 500)
    if use_price_filter:
        min_price, max_price = st.slider(
            "Faixa de Preço (US$):",
            0, 1000, (0, 500)
        )

with col2:
    use_neighbourhood_filter = st.checkbox("Filtrar por Bairro")
    neighbourhoods = []
    if use_neighbourhood_filter and 'neighbourhood_group' in st.session_state.data.columns:
        neighbourhoods = st.multiselect(
            "Selecione os Bairros:",
            options=st.session_state.data['neighbourhood_group'].unique(),
            default=st.session_state.data['neighbourhood_group'].unique()
        )

# Aplicar filtros aos dados
filtered_data = st.session_state.data.copy()

if use_price_filter:
    filtered_data = filtered_data[(filtered_data['price'] >= min_price) & (filtered_data['price'] <= max_price)]

if use_neighbourhood_filter and 'neighbourhood_group' in filtered_data.columns and neighbourhoods:
    filtered_data = filtered_data[filtered_data['neighbourhood_group'].isin(neighbourhoods)]

st.write(f"Dados após filtragem: {filtered_data.shape[0]:,} registros (de {st.session_state.data.shape[0]:,})")

# Pré-processamento e divisão dos dados
if st.button("Pré-processar Dados"):
    with st.spinner("Pré-processando dados..."):
        try:
            # Pré-processar dados
            X_train_processed, X_test_processed, y_train, y_test, preprocessor, numeric_cols, categorical_cols = preprocess_airbnb_data(
                filtered_data, 
                target_col='price', 
                test_size=test_size,
                random_state=random_state
            )
            
            # Armazenar no session state
            st.session_state.X_train = X_train_processed
            st.session_state.X_test = X_test_processed
            st.session_state.y_train = y_train
            st.session_state.y_test = y_test
            st.session_state.preprocessor = preprocessor
            st.session_state.numeric_cols = numeric_cols
            st.session_state.categorical_cols = categorical_cols
            st.session_state.feature_names = get_feature_names(preprocessor, numeric_cols, categorical_cols)
            
            st.success("Dados pré-processados com sucesso!")
            
            # Exibir informações sobre os conjuntos de dados
            col1, col2 = st.columns(2)
            with col1:
                st.write(f"**Conjunto de Treino:** {X_train_processed.shape[0]:,} registros, {X_train_processed.shape[1]:,} features")
            
            with col2:
                st.write(f"**Conjunto de Teste:** {X_test_processed.shape[0]:,} registros, {X_test_processed.shape[1]:,} features")
            
            # Exibir distribuição do target em treino e teste
            fig, ax = plt.subplots(1, 2, figsize=(12, 5))
            
            if st.session_state.target_type == 'continuous':
                sns.histplot(y_train, kde=True, ax=ax[0])
                ax[0].set_title('Distribuição do Target (Treino)')
                
                sns.histplot(y_test, kde=True, ax=ax[1])
                ax[1].set_title('Distribuição do Target (Teste)')
            else:
                sns.countplot(x=y_train, ax=ax[0])
                ax[0].set_title('Distribuição do Target Binário (Treino)')
                
                sns.countplot(x=y_test, ax=ax[1])
                ax[1].set_title('Distribuição do Target Binário (Teste)')
            
            st.pyplot(fig)
            
        except Exception as e:
            st.error(f"Erro durante o pré-processamento: {e}")

# Treinamento dos modelos
st.header("Treinamento dos Modelos")

if 'X_train' in st.session_state and st.session_state.X_train is not None:
    is_classification = st.session_state.target_type == 'binary'
    
    if st.button("Treinar Todos os Modelos"):
        with st.spinner("Treinando modelos... Isso pode levar alguns minutos."):
            start_time = time.time()
            
            # Treinar todos os modelos
            results = train_all_models(
                st.session_state.X_train,
                st.session_state.y_train,
                st.session_state.X_test,
                st.session_state.y_test,
                is_classification=is_classification
            )
            
            # Armazenar resultados no session state
            st.session_state.models_results = results
            st.session_state.models_trained = True
            
            total_time = time.time() - start_time
            st.success(f"Todos os modelos foram treinados com sucesso! (Tempo total: {total_time:.2f} segundos)")
            
            # Exibir resumo dos resultados
            st.subheader("Resumo dos Resultados")
            
            if is_classification:
                metrics_summary = pd.DataFrame({
                    'Modelo': [model_name for model_name in results.keys()],
                    'Acurácia': [results[model_name]['metrics']['accuracy'] for model_name in results.keys()],
                    'F1-Score': [results[model_name]['metrics']['f1_score'] for model_name in results.keys()],
                    'Tempo de Treinamento (s)': [results[model_name]['training_time'] for model_name in results.keys()]
                })
                metrics_summary = metrics_summary.sort_values('Acurácia', ascending=False)
            else:
                metrics_summary = pd.DataFrame({
                    'Modelo': [model_name for model_name in results.keys()],
                    'RMSE': [results[model_name]['metrics']['rmse'] for model_name in results.keys()],
                    'R²': [results[model_name]['metrics']['r2'] for model_name in results.keys()],
                    'Tempo de Treinamento (s)': [results[model_name]['training_time'] for model_name in results.keys()]
                })
                metrics_summary = metrics_summary.sort_values('R²', ascending=False)
            
            st.dataframe(metrics_summary)
            
            # Visualização dos resultados
            st.subheader("Comparação de Desempenho")
            
            # Gráfico de barras de desempenho
            fig, ax = plt.subplots(figsize=(12, 6))
            
            if is_classification:
                models = metrics_summary['Modelo']
                accuracies = metrics_summary['Acurácia']
                f1_scores = metrics_summary['F1-Score']
                
                x = np.arange(len(models))
                width = 0.35
                
                rects1 = ax.bar(x - width/2, accuracies, width, label='Acurácia')
                rects2 = ax.bar(x + width/2, f1_scores, width, label='F1-Score')
                
                ax.set_ylabel('Pontuação')
                ax.set_title('Acurácia e F1-Score por Modelo')
                ax.set_xticks(x)
                ax.set_xticklabels(models, rotation=45, ha='right')
                ax.legend()
                
                ax.bar_label(rects1, padding=3, fmt='%.3f')
                ax.bar_label(rects2, padding=3, fmt='%.3f')
                
            else:
                models = metrics_summary['Modelo']
                rmse_values = metrics_summary['RMSE']
                r2_values = metrics_summary['R²']
                
                # Normalizar RMSE para estar na mesma escala do R²
                max_rmse = max(rmse_values)
                normalized_rmse = [1 - (rmse / max_rmse) for rmse in rmse_values]
                
                x = np.arange(len(models))
                width = 0.35
                
                rects1 = ax.bar(x - width/2, normalized_rmse, width, label='RMSE (normalizado)')
                rects2 = ax.bar(x + width/2, r2_values, width, label='R²')
                
                ax.set_ylabel('Pontuação')
                ax.set_title('Métricas de Desempenho por Modelo')
                ax.set_xticks(x)
                ax.set_xticklabels(models, rotation=45, ha='right')
                ax.legend()
                
                ax.bar_label(rects1, padding=3, fmt='%.3f')
                ax.bar_label(rects2, padding=3, fmt='%.3f')
                
            fig.tight_layout()
            st.pyplot(fig)
            
            # Gráfico de tempo de treinamento
            fig, ax = plt.subplots(figsize=(12, 6))
            
            training_times = metrics_summary['Tempo de Treinamento (s)']
            
            ax.bar(models, training_times)
            ax.set_ylabel('Tempo (segundos)')
            ax.set_title('Tempo de Treinamento por Modelo')
            ax.set_xticklabels(models, rotation=45, ha='right')
            
            for i, v in enumerate(training_times):
                ax.text(i, v + 0.1, f"{v:.2f}s", ha='center')
            
            fig.tight_layout()
            st.pyplot(fig)
    
    else:
        st.info("Clique no botão acima para treinar todos os modelos.")
else:
    st.warning("Por favor, primeiro pré-processe os dados antes de treinar os modelos.")

# Mostrar informações sobre os modelos
st.header("Informações sobre os Modelos Implementados")
st.markdown("""
## Modelos Obrigatórios

### Regressão Linear
- **Algoritmo**: Minimiza o erro quadrático entre as previsões e os valores reais
- **Vantagens**: Simples, interpretável, computacionalmente eficiente
- **Desvantagens**: Assume relação linear, sensível a outliers

### Regressão Logística (para classificação binária)
- **Algoritmo**: Modela a probabilidade de uma classe usando a função logística
- **Vantagens**: Fornece probabilidades, interpretável
- **Desvantagens**: Assume fronteiras de decisão lineares

## Modelos Adicionais

### Árvore de Decisão
- **Algoritmo**: Divide os dados recursivamente com base em regras de decisão
- **Vantagens**: Fácil interpretação, captura relações não-lineares
- **Desvantagens**: Tendência a overfitting

### Random Forest
- **Algoritmo**: Ensemble de árvores de decisão treinadas em diferentes subconjuntos dos dados
- **Vantagens**: Robusto a outliers, boa performance, reduz overfitting
- **Desvantagens**: Menos interpretável, mais custoso computacionalmente

### XGBoost
- **Algoritmo**: Gradient boosting otimizado, constrói árvores sequencialmente
- **Vantagens**: Alta performance, eficiente, robusto a vários tipos de dados
- **Desvantagens**: Requer ajuste cuidadoso de hiperparâmetros

### SVR/SVM
- **Algoritmo**: Encontra o hiperplano que maximiza a margem entre as classes
- **Vantagens**: Eficaz em espaços de alta dimensão, versátil com diferentes kernels
- **Desvantagens**: Escala mal com grandes volumes de dados, sensível à escolha de hiperparâmetros

### KNN
- **Algoritmo**: Classifica/prevê com base nos k vizinhos mais próximos
- **Vantagens**: Simples, intuitivo, não faz suposições sobre os dados
- **Desvantagens**: Computacionalmente intensivo para grandes datasets, sensível a features irrelevantes

### Rede Neural (MLP)
- **Algoritmo**: Rede de neurônios artificiais com uma ou mais camadas ocultas
- **Vantagens**: Capaz de modelar relações altamente não-lineares, versátil
- **Desvantagens**: Requer mais dados, propenso a overfitting, menos interpretável
""")
