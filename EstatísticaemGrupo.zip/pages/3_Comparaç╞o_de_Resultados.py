import streamlit as st
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from utils.model_evaluation import (
    compare_regression_models, 
    compare_classification_models,
    plot_regression_scatter,
    plot_regression_residuals,
    plot_classification_confusion_matrix,
    calculate_rmse
)
from utils.visualization import (
    plot_feature_importance,
    plot_regression_coefficients,
    plot_distribution_comparison
)

# Configuração da página
st.set_page_config(
    page_title="Comparação de Resultados - Análise Comparativa",
    page_icon="📈",
    layout="wide"
)

# Título da página
st.title("Comparação de Resultados dos Modelos")
st.write("""
Esta página apresenta uma análise detalhada dos resultados de todos os modelos treinados,
incluindo métricas de desempenho, visualizações e insights para interpretação.
""")

# Verificar se os dados foram carregados
if 'data' not in st.session_state or st.session_state.data is None:
    st.warning("Por favor, carregue os dados na página inicial antes de continuar.")
    st.stop()

# Verificar se os modelos foram treinados
if 'models_trained' not in st.session_state or not st.session_state.models_trained:
    st.warning("Por favor, treine os modelos na página de Treinamento antes de acessar esta página.")
    st.stop()

# Tabs para diferentes análises
tab1, tab2, tab3, tab4 = st.tabs([
    "Comparação de Métricas", 
    "Análise Visual", 
    "Importância de Features", 
    "Análise Detalhada"
])

# Determinar se estamos trabalhando com classificação ou regressão
is_classification = st.session_state.target_type == 'binary'

# Comparação de métricas entre modelos
with tab1:
    st.header("Comparação de Métricas entre Modelos")
    
    if is_classification:
        comparison_df = compare_classification_models(st.session_state.models_results)
        st.write("### Métricas de Classificação")
        st.dataframe(comparison_df)
        
        # Gráfico de barras para métricas selecionadas
        st.write("### Visualização Comparativa")
        metrics_to_plot = st.multiselect(
            "Selecione as métricas para visualizar:",
            options=['Acurácia', 'Precisão', 'Recall', 'F1-Score'],
            default=['Acurácia', 'F1-Score']
        )
        
        if metrics_to_plot:
            fig, ax = plt.subplots(figsize=(12, 6))
            comparison_df.set_index('Modelo')[metrics_to_plot].plot(kind='bar', ax=ax)
            ax.set_ylabel('Pontuação')
            ax.set_title('Comparação de Métricas entre Modelos')
            ax.legend(loc='best')
            st.pyplot(fig)
        
    else:
        comparison_df = compare_regression_models(st.session_state.models_results)
        st.write("### Métricas de Regressão")
        st.dataframe(comparison_df)
        
        # Gráfico de barras para métricas selecionadas
        st.write("### Visualização Comparativa")
        metrics_to_plot = st.multiselect(
            "Selecione as métricas para visualizar:",
            options=['RMSE', 'MAE', 'R²', 'Variância Explicada'],
            default=['RMSE', 'R²']
        )
        
        if metrics_to_plot:
            # Normalizar RMSE para melhor visualização (valores menores são melhores)
            if 'RMSE' in metrics_to_plot:
                plot_df = comparison_df.copy()
                max_rmse = plot_df['RMSE'].max()
                plot_df['RMSE (Normalizado)'] = 1 - (plot_df['RMSE'] / max_rmse)
                metrics_to_plot = [m if m != 'RMSE' else 'RMSE (Normalizado)' for m in metrics_to_plot]
                
                fig, ax = plt.subplots(figsize=(12, 6))
                plot_df.set_index('Modelo')[metrics_to_plot].plot(kind='bar', ax=ax)
                ax.set_ylabel('Pontuação')
                ax.set_title('Comparação de Métricas entre Modelos (RMSE normalizado)')
                ax.legend(loc='best')
            else:
                fig, ax = plt.subplots(figsize=(12, 6))
                comparison_df.set_index('Modelo')[metrics_to_plot].plot(kind='bar', ax=ax)
                ax.set_ylabel('Pontuação')
                ax.set_title('Comparação de Métricas entre Modelos')
                ax.legend(loc='best')
                
            st.pyplot(fig)
        
        # Tabela com ranking dos modelos
        st.write("### Ranking dos Modelos")
        ranking_cols = ['Modelo', 'RMSE', 'R²', 'Variância Explicada']
        st.dataframe(comparison_df[ranking_cols])
    
    # Análise de tempo de execução
    st.write("### Análise de Tempo de Execução")
    
    time_cols = ['Modelo', 'Tempo de Treinamento (s)', 'Tempo de Predição (s)']
    time_df = comparison_df[time_cols].sort_values('Tempo de Treinamento (s)')
    
    fig, ax = plt.subplots(figsize=(10, 6))
    time_df.set_index('Modelo').plot(kind='bar', ax=ax)
    ax.set_ylabel('Tempo (segundos)')
    ax.set_title('Tempo de Treinamento e Predição por Modelo')
    ax.legend(loc='best')
    
    for container in ax.containers:
        ax.bar_label(container, fmt='%.2f')
    
    st.pyplot(fig)
    
    # Análise de compromisso entre desempenho e tempo
    st.write("### Compromisso entre Desempenho e Tempo")
    
    if is_classification:
        tradeoff_df = comparison_df[['Modelo', 'Acurácia', 'Tempo de Treinamento (s)']]
        performance_metric = 'Acurácia'
    else:
        tradeoff_df = comparison_df[['Modelo', 'R²', 'Tempo de Treinamento (s)']]
        performance_metric = 'R²'
    
    fig, ax = plt.subplots(figsize=(10, 6))
    scatter = ax.scatter(
        tradeoff_df['Tempo de Treinamento (s)'],
        tradeoff_df[performance_metric],
        s=100
    )
    
    # Adicionar rótulos dos modelos
    for i, model in enumerate(tradeoff_df['Modelo']):
        ax.annotate(
            model,
            (tradeoff_df['Tempo de Treinamento (s)'].iloc[i], tradeoff_df[performance_metric].iloc[i]),
            xytext=(5, 5),
            textcoords='offset points'
        )
    
    ax.set_xlabel('Tempo de Treinamento (s)')
    ax.set_ylabel(performance_metric)
    ax.set_title(f'Compromisso entre {performance_metric} e Tempo de Treinamento')
    ax.grid(True)
    
    st.pyplot(fig)

# Análise Visual dos Resultados
with tab2:
    st.header("Análise Visual dos Resultados")
    
    # Selecionar modelo para visualizar
    model_names = list(st.session_state.models_results.keys())
    selected_model = st.selectbox("Selecione um modelo para visualizar:", model_names)
    
    if selected_model:
        model_data = st.session_state.models_results[selected_model]
        model = model_data['model']
        metrics = model_data['metrics']
        
        if is_classification:
            # Visualizações para classificação
            st.write(f"### Análise do Modelo: {selected_model}")
            
            col1, col2 = st.columns(2)
            
            with col1:
                st.write("**Métricas:**")
                st.write(f"- Acurácia: {metrics['accuracy']:.4f}")
                st.write(f"- Precisão: {metrics['precision']:.4f}")
                st.write(f"- Recall: {metrics['recall']:.4f}")
                st.write(f"- F1-Score: {metrics['f1_score']:.4f}")
                if 'roc_auc' in metrics:
                    st.write(f"- AUC-ROC: {metrics['roc_auc']:.4f}")
            
            with col2:
                st.write("**Matriz de Confusão:**")
                fig = plot_classification_confusion_matrix(
                    selected_model,
                    st.session_state.y_test,
                    metrics['y_pred']
                )
                st.pyplot(fig)
            
            # ROC Curve se disponível
            if 'y_prob' in metrics:
                from sklearn.metrics import roc_curve, auc
                
                st.write("### Curva ROC")
                fpr, tpr, _ = roc_curve(st.session_state.y_test, metrics['y_prob'])
                roc_auc = auc(fpr, tpr)
                
                fig, ax = plt.subplots(figsize=(8, 6))
                ax.plot(fpr, tpr, label=f'AUC = {roc_auc:.4f}')
                ax.plot([0, 1], [0, 1], 'k--')
                ax.set_xlabel('Taxa de Falsos Positivos')
                ax.set_ylabel('Taxa de Verdadeiros Positivos')
                ax.set_title(f'Curva ROC - {selected_model}')
                ax.legend(loc='lower right')
                st.pyplot(fig)
        
        else:
            # Visualizações para regressão
            st.write(f"### Análise do Modelo: {selected_model}")
            
            col1, col2 = st.columns(2)
            
            with col1:
                st.write("**Métricas:**")
                st.write(f"- RMSE: {metrics['rmse']:.4f}")
                st.write(f"- MAE: {metrics['mae']:.4f}")
                st.write(f"- R²: {metrics['r2']:.4f}")
                st.write(f"- Variância Explicada: {metrics['explained_variance']:.4f}")
            
            with col2:
                # Gráfico de dispersão: Valores reais vs. previstos
                fig = plot_regression_scatter(
                    selected_model,
                    st.session_state.y_test,
                    metrics['y_pred']
                )
                st.pyplot(fig)
            
            # Gráfico de resíduos
            st.write("### Análise de Resíduos")
            fig = plot_regression_residuals(
                selected_model,
                st.session_state.y_test,
                metrics['y_pred']
            )
            st.pyplot(fig)
            
            # Distribuição de valores reais vs. previstos
            st.write("### Distribuição: Valores Reais vs. Previstos")
            fig = plot_distribution_comparison(
                st.session_state.y_test,
                metrics['y_pred']
            )
            st.pyplot(fig)

# Análise de Importância de Features
with tab3:
    st.header("Análise de Importância de Features")
    
    # Selecionar modelo para visualizar importância de features
    model_names = list(st.session_state.models_results.keys())
    selected_model = st.selectbox(
        "Selecione um modelo para visualizar importância de features:",
        model_names,
        key="feature_importance_selector"
    )
    
    if selected_model:
        model_data = st.session_state.models_results[selected_model]
        model = model_data['model']
        
        # Tentar extrair importância de features ou coeficientes
        feature_names = getattr(st.session_state, 'feature_names', None)
        
        fig = None
        
        # Para modelos lineares (coeficientes)
        if hasattr(model, 'coef_'):
            fig = plot_regression_coefficients(model, feature_names)
            title = "Coeficientes do Modelo"
        
        # Para modelos baseados em árvores e outros com feature_importances_
        elif hasattr(model, 'feature_importances_'):
            fig = plot_feature_importance(model, feature_names)
            title = "Importância das Features"
        
        if fig:
            st.write(f"### {title} - {selected_model}")
            st.pyplot(fig)
        else:
            st.info(f"O modelo {selected_model} não suporta visualização direta de importância de features.")
            
            # Para regressão logística e alguns outros modelos que não têm feature_importances_
            if hasattr(model, 'coef_') and len(model.coef_.shape) > 1:
                st.write("### Magnitudes dos Coeficientes")
                if feature_names:
                    coef_magnitudes = np.abs(model.coef_[0])
                    feature_importance = pd.DataFrame({
                        'Feature': feature_names[:len(coef_magnitudes)],
                        'Importância Absoluta': coef_magnitudes
                    }).sort_values('Importância Absoluta', ascending=False)
                    
                    # Mostrar as top 20 features
                    st.dataframe(feature_importance.head(20))
                    
                    # Plotar top 15 features
                    fig, ax = plt.subplots(figsize=(10, 8))
                    top_features = feature_importance.head(15)
                    ax.barh(top_features['Feature'], top_features['Importância Absoluta'])
                    ax.set_xlabel('Importância Absoluta (Magnitude do Coeficiente)')
                    ax.set_title(f'Top 15 Features por Importância - {selected_model}')
                    ax.invert_yaxis()  # Para que a feature mais importante apareça no topo
                    st.pyplot(fig)
                else:
                    st.warning("Nomes das features não disponíveis para visualização.")
        
        # Permutation importance se os outros métodos falharem
        if not fig and not hasattr(model, 'coef_'):
            st.write("### Análise Alternativa de Importância")
            st.info("""
            Para este modelo, podemos usar importância por permutação para entender quais features são mais relevantes.
            Este método mede o aumento no erro de previsão do modelo quando uma única feature é embaralhada.
            
            Nota: Este cálculo pode ser computacionalmente intensivo para grandes datasets.
            """)
            
            if st.button("Calcular Importância por Permutação"):
                with st.spinner("Calculando importância por permutação... Isso pode levar algum tempo."):
                    try:
                        from sklearn.inspection import permutation_importance
                        
                        result = permutation_importance(
                            model, 
                            st.session_state.X_test, 
                            st.session_state.y_test,
                            n_repeats=5,
                            random_state=42
                        )
                        
                        feature_importance = pd.DataFrame({
                            'Feature': feature_names[:len(result.importances_mean)] if feature_names else [f"Feature {i}" for i in range(len(result.importances_mean))],
                            'Importância': result.importances_mean
                        }).sort_values('Importância', ascending=False)
                        
                        # Mostrar as top 20 features
                        st.dataframe(feature_importance.head(20))
                        
                        # Plotar top 15 features
                        fig, ax = plt.subplots(figsize=(10, 8))
                        top_features = feature_importance.head(15)
                        ax.barh(top_features['Feature'], top_features['Importância'])
                        ax.set_xlabel('Importância por Permutação')
                        ax.set_title(f'Top 15 Features por Importância - {selected_model}')
                        ax.invert_yaxis()
                        st.pyplot(fig)
                    except Exception as e:
                        st.error(f"Erro ao calcular importância por permutação: {e}")

# Análise Detalhada
with tab4:
    st.header("Análise Detalhada e Insights")
    
    # Resumo da análise comparativa
    st.write("### Resumo da Análise Comparativa dos Modelos")
    
    if is_classification:
        comparison_df = compare_classification_models(st.session_state.models_results)
        best_model = comparison_df.iloc[0]['Modelo']
        best_metric = comparison_df.iloc[0]['Acurácia']
        
        st.write(f"""
        **Melhor Modelo**: {best_model} com acurácia de {best_metric:.4f}
        
        #### Insights da Análise de Classificação:
        
        1. **Desempenho Geral**: O modelo {best_model} apresentou o melhor desempenho em termos de acurácia, 
           demonstrando sua capacidade de classificar corretamente as amostras do conjunto de teste.
        
        2. **Compromisso Precisão-Recall**: Os modelos apresentaram diferentes comportamentos em termos de precisão e recall,
           o que indica diferentes capacidades de lidar com falsos positivos e falsos negativos.
        
        3. **Tempo de Processamento**: Os modelos variam significativamente em termos de tempo de treinamento,
           com alguns oferecendo bom desempenho a um custo computacional menor.
        """)
        
        # Análise específica para cada modelo
        st.write("### Análise por Modelo")
        
        for model_name in comparison_df['Modelo']:
            metrics = st.session_state.models_results[model_name]['metrics']
            
            with st.expander(f"Análise Detalhada: {model_name}"):
                col1, col2 = st.columns(2)
                
                with col1:
                    st.write("**Métricas:**")
                    st.write(f"- Acurácia: {metrics['accuracy']:.4f}")
                    st.write(f"- Precisão: {metrics['precision']:.4f}")
                    st.write(f"- Recall: {metrics['recall']:.4f}")
                    st.write(f"- F1-Score: {metrics['f1_score']:.4f}")
                    if 'roc_auc' in metrics:
                        st.write(f"- AUC-ROC: {metrics['roc_auc']:.4f}")
                
                with col2:
                    st.write("**Análise de Confusão:**")
                    fig = plot_classification_confusion_matrix(
                        model_name,
                        st.session_state.y_test,
                        metrics['y_pred']
                    )
                    st.pyplot(fig)
                
                st.write("**Interpretação:**")
                
                # Interpretações específicas para cada modelo
                if model_name == 'Regressão Logística':
                    st.write("""
                    A Regressão Logística é um modelo linear para classificação que estima a probabilidade de uma amostra pertencer a uma classe.
                    - **Pontos Fortes**: Interpretabilidade, velocidade de treinamento e previsão.
                    - **Limitações**: Assume fronteiras de decisão lineares, pode ter desempenho inferior em problemas complexos.
                    """)
                
                elif model_name == 'Árvore de Decisão':
                    st.write("""
                    A Árvore de Decisão divide os dados em subconjuntos mais puros com base em regras de decisão em formato de árvore.
                    - **Pontos Fortes**: Fácil interpretação, captura relações não-lineares.
                    - **Limitações**: Tendência a overfitting, especialmente em árvores profundas.
                    """)
                
                elif model_name == 'Random Forest':
                    st.write("""
                    O Random Forest é um ensemble de árvores de decisão treinadas em diferentes subconjuntos dos dados.
                    - **Pontos Fortes**: Robustez ao overfitting, boa performance, captura relações complexas.
                    - **Limitações**: Menor interpretabilidade, maior custo computacional.
                    """)
                
                elif model_name == 'XGBoost':
                    st.write("""
                    O XGBoost é um algoritmo de gradient boosting otimizado que constrói árvores sequencialmente.
                    - **Pontos Fortes**: Alta performance preditiva, eficiência, robustez.
                    - **Limitações**: Mais parâmetros para ajustar, menor interpretabilidade.
                    """)
                
                elif model_name == 'SVM':
                    st.write("""
                    O SVM (Support Vector Machine) encontra o hiperplano que maximiza a margem entre as classes.
                    - **Pontos Fortes**: Eficaz em espaços de alta dimensão, versatilidade com diferentes kernels.
                    - **Limitações**: Escalonamento com grandes volumes de dados, sensibilidade aos hiperparâmetros.
                    """)
                
                elif model_name == 'KNN':
                    st.write("""
                    O KNN (K-Nearest Neighbors) classifica com base nos k vizinhos mais próximos no espaço de features.
                    - **Pontos Fortes**: Intuitivo, não-paramétrico, adaptativo.
                    - **Limitações**: Sensível à escala das features, custoso para grandes datasets.
                    """)
                
                elif model_name == 'Rede Neural (MLP)':
                    st.write("""
                    A Rede Neural MLP (Multi-Layer Perceptron) consiste em camadas de neurônios que aprendem representações complexas.
                    - **Pontos Fortes**: Capacidade de modelar relações altamente não-lineares, versatilidade.
                    - **Limitações**: Requer mais dados, propenso a overfitting, "caixa preta".
                    """)
    
    else:  # Regressão
        comparison_df = compare_regression_models(st.session_state.models_results)
        best_model_r2 = comparison_df.iloc[0]['Modelo']
        best_r2 = comparison_df.iloc[0]['R²']
        
        # Encontrar modelo com menor RMSE
        best_rmse_model = comparison_df.sort_values('RMSE').iloc[0]['Modelo']
        best_rmse = comparison_df.sort_values('RMSE').iloc[0]['RMSE']
        
        st.write(f"""
        **Melhor Modelo (R²)**: {best_model_r2} com R² de {best_r2:.4f}
        
        **Melhor Modelo (RMSE)**: {best_rmse_model} com RMSE de {best_rmse:.4f}
        
        #### Insights da Análise de Regressão:
        
        1. **Desempenho Geral**: O modelo {best_model_r2} apresentou o melhor desempenho em termos de R², 
           explicando {best_r2:.2%} da variância nos preços das acomodações do Airbnb.
        
        2. **Precisão das Previsões**: O modelo {best_rmse_model} obteve o menor erro (RMSE),
           indicando maior precisão nas previsões de valores específicos.
        
        3. **Compromisso Complexidade-Desempenho**: Modelos mais complexos como {best_model_r2} tendem a capturar melhor
           as relações nos dados, mas com custo computacional maior e possível overfitting.
        
        4. **Fatores Determinantes**: A localização, tipo de propriedade e características específicas como
           número de quartos e disponibilidade foram identificados como fatores importantes na determinação dos preços.
        """)
        
        # Análise específica para cada modelo
        st.write("### Análise por Modelo")
        
        for model_name in comparison_df['Modelo']:
            metrics = st.session_state.models_results[model_name]['metrics']
            
            with st.expander(f"Análise Detalhada: {model_name}"):
                col1, col2 = st.columns(2)
                
                with col1:
                    st.write("**Métricas:**")
                    st.write(f"- RMSE: {metrics['rmse']:.4f}")
                    st.write(f"- MAE: {metrics['mae']:.4f}")
                    st.write(f"- R²: {metrics['r2']:.4f}")
                    st.write(f"- Variância Explicada: {metrics['explained_variance']:.4f}")
                
                with col2:
                    fig = plot_regression_scatter(
                        model_name,
                        st.session_state.y_test,
                        metrics['y_pred']
                    )
                    st.pyplot(fig)
                
                st.write("**Análise de Resíduos:**")
                fig = plot_regression_residuals(
                    model_name,
                    st.session_state.y_test,
                    metrics['y_pred']
                )
                st.pyplot(fig)
                
                st.write("**Interpretação:**")
                
                # Interpretações específicas para cada modelo
                if model_name == 'Regressão Linear':
                    st.write("""
                    A Regressão Linear modela a relação entre features e target como uma função linear.
                    - **Pontos Fortes**: Simplicidade, interpretabilidade, eficiência computacional.
                    - **Limitações**: Assume relação linear, sensível a outliers, pode não capturar relações complexas.
                    - **Observações**: Os resíduos mostram padrões que indicam que algumas relações não-lineares não foram capturadas.
                    """)
                
                elif model_name == 'Árvore de Decisão':
                    st.write("""
                    A Árvore de Decisão para regressão divide os dados em regiões e atribui um valor constante para cada região.
                    - **Pontos Fortes**: Fácil interpretação, captura relações não-lineares, insensível à escala das features.
                    - **Limitações**: Tendência a overfitting, previsões discretizadas (em degraus).
                    - **Observações**: As previsões têm um aspecto "escalonado" devido à natureza da árvore.
                    """)
                
                elif model_name == 'Random Forest':
                    st.write("""
                    O Random Forest para regressão combina várias árvores de decisão, onde cada árvore é treinada em um subconjunto dos dados.
                    - **Pontos Fortes**: Robustez, redução do overfitting, boa performance preditiva.
                    - **Limitações**: Interpretabilidade mais complexa, maior custo computacional.
                    - **Observações**: Tende a ter uma performance equilibrada, mas pode subestimar valores extremos.
                    """)
                
                elif model_name == 'XGBoost':
                    st.write("""
                    O XGBoost é um algoritmo de gradient boosting que constrói árvores sequencialmente, com cada nova árvore corrigindo os erros das anteriores.
                    - **Pontos Fortes**: Alta performance preditiva, eficiência, robustez a outliers e dados desbalanceados.
                    - **Limitações**: Requer ajuste cuidadoso de hiperparâmetros, menos interpretável.
                    - **Observações**: Geralmente um dos modelos com melhor desempenho, especialmente em estruturas de dados complexas.
                    """)
                
                elif model_name == 'SVR':
                    st.write("""
                    O SVR (Support Vector Regression) estende o conceito do SVM para problemas de regressão.
                    - **Pontos Fortes**: Eficaz com múltiplas dimensões, robusto contra overfitting com kernel adequado.
                    - **Limitações**: Custo computacional elevado para grandes datasets, sensível à escolha de parâmetros.
                    - **Observações**: Em problemas com muitas features, pode apresentar boa generalização.
                    """)
                
                elif model_name == 'KNN':
                    st.write("""
                    O KNN Regressor estima valores como a média dos valores dos k vizinhos mais próximos no espaço de features.
                    - **Pontos Fortes**: Simples, intuitivo, sem suposições sobre a forma da relação.
                    - **Limitações**: Computacionalmente intensivo para grandes conjuntos de dados, sensível à escolha de k.
                    - **Observações**: Performace pode variar muito dependendo da estrutura dos dados e valor de k.
                    """)
                
                elif model_name == 'Rede Neural (MLP)':
                    st.write("""
                    A Rede Neural MLP (Multi-Layer Perceptron) para regressão consiste em camadas de neurônios que aprendem representações complexas.
                    - **Pontos Fortes**: Capacidade de capturar relações altamente não-lineares e complexas.
                    - **Limitações**: Requer mais dados para treinamento, propenso a overfitting sem regularização adequada.
                    - **Observações**: A arquitetura da rede (número de camadas e neurônios) tem grande impacto no desempenho.
                    """)
    
    # Conclusões e Recomendações
    st.write("### Conclusões e Recomendações")
    
    if is_classification:
        st.write("""
        #### Conclusões Gerais:
        
        1. **Desempenho dos Modelos**: Os modelos mais complexos como Random Forest, XGBoost e Redes Neurais tendem a ter melhor 
           desempenho em termos de acurácia e F1-score, demonstrando sua capacidade de capturar relações complexas nos dados.
        
        2. **Compromisso Precisão-Recall**: Dependendo do contexto do problema, pode ser mais importante maximizar precisão 
           (minimizar falsos positivos) ou recall (minimizar falsos negativos). Diferentes modelos mostram diferentes pontos 
           fortes nessas métricas.
        
        3. **Eficiência Computacional**: Modelos mais simples como Regressão Logística e KNN oferecem treinamento mais rápido, 
           o que pode ser crucial para aplicações que requerem atualização frequente.
        
        #### Recomendações:
        
        1. **Escolha do Modelo**: Para este problema específico, o modelo mais recomendado seria o que apresentou o melhor 
           balanço entre acurácia e interpretabilidade, considerando as necessidades específicas do contexto de aplicação.
        
        2. **Ajuste de Hiperparâmetros**: Embora tenhamos usado configurações padrão para a maioria dos modelos, uma otimização 
           mais detalhada dos hiperparâmetros poderia melhorar ainda mais o desempenho, especialmente para modelos como 
           XGBoost e Redes Neurais.
        
        3. **Engenharia de Features**: A análise de importância de features sugere que certas características têm maior 
           impacto na classificação. Explorar a engenharia dessas features poderia melhorar ainda mais os resultados.
        
        4. **Abordagem em Produção**: Para implementação em produção, recomenda-se um ensemble de modelos ou o uso do 
           XGBoost com parametrização cuidadosa, devido ao seu equilíbrio entre desempenho e eficiência.
        """)
    else:
        st.write("""
        #### Conclusões Gerais:
        
        1. **Desempenho dos Modelos**: Os modelos baseados em árvores (Random Forest e XGBoost) apresentaram o melhor 
           desempenho em termos de R² e RMSE, demonstrando sua capacidade de capturar relações não-lineares complexas 
           nos dados de preços do Airbnb.
        
        2. **Importância da Localização**: A análise de importância de features mostra consistentemente que variáveis 
           relacionadas à localização (bairro, coordenadas geográficas) estão entre os preditores mais importantes, 
           confirmando a máxima imobiliária "localização, localização, localização".
        
        3. **Variabilidade Explicada**: O melhor modelo conseguiu explicar aproximadamente {best_r2:.2%} da variância nos 
           preços, indicando que existe uma parte significativa da variabilidade que não é capturada apenas pelas 
           características disponíveis nos dados.
        
        4. **Eficiência vs. Precisão**: Modelos mais simples como Regressão Linear oferecem maior velocidade e interpretabilidade, 
           mas com desempenho significativamente inferior em termos de métricas de erro.
        
        #### Recomendações:
        
        1. **Escolha do Modelo**: Para aplicações onde a precisão é crítica, recomenda-se o uso de {best_model_r2} ou {best_rmse_model}, 
           dependendo se a prioridade é maximizar a variância explicada ou minimizar o erro absoluto.
        
        2. **Ajuste de Hiperparâmetros**: Uma otimização mais detalhada dos hiperparâmetros, especialmente para XGBoost e 
           Random Forest, poderia melhorar ainda mais o desempenho.
        
        3. **Features Adicionais**: Incorporar features adicionais como distância a pontos turísticos, qualidade do transporte 
           público e indicadores socioeconômicos dos bairros poderia ajudar a explicar mais da variabilidade nos preços.
        
        4. **Abordagem em Produção**: Em um cenário de produção, recomenda-se implementar o modelo {best_model_r2} com 
           monitoramento contínuo do desempenho e atualizações periódicas para capturar mudanças sazonais ou tendências 
           de mercado.
        """)
    
    # Métricas finais
    st.write("### Métricas Finais do Melhor Modelo")
    
    if is_classification:
        best_model_name = comparison_df.iloc[0]['Modelo']
        best_metrics = st.session_state.models_results[best_model_name]['metrics']
        
        col1, col2, col3, col4 = st.columns(4)
        col1.metric("Acurácia", f"{best_metrics['accuracy']:.4f}")
        col2.metric("Precisão", f"{best_metrics['precision']:.4f}")
        col3.metric("Recall", f"{best_metrics['recall']:.4f}")
        col4.metric("F1-Score", f"{best_metrics['f1_score']:.4f}")
        
        if 'roc_auc' in best_metrics:
            st.metric("AUC-ROC", f"{best_metrics['roc_auc']:.4f}")
    else:
        best_model_name = comparison_df.iloc[0]['Modelo']
        best_metrics = st.session_state.models_results[best_model_name]['metrics']
        
        col1, col2, col3, col4 = st.columns(4)
        col1.metric("R²", f"{best_metrics['r2']:.4f}")
        col2.metric("RMSE", f"{best_metrics['rmse']:.4f}")
        col3.metric("MAE", f"{best_metrics['mae']:.4f}")
        col4.metric("Variância Explicada", f"{best_metrics['explained_variance']:.4f}")

# Botão para baixar resultados como CSV
st.sidebar.header("Exportar Resultados")

@st.cache_data
def convert_df_to_csv(df):
    return df.to_csv(index=False).encode('utf-8')

if 'models_results' in st.session_state and st.session_state.models_results:
    if is_classification:
        export_df = compare_classification_models(st.session_state.models_results)
    else:
        export_df = compare_regression_models(st.session_state.models_results)
    
    csv = convert_df_to_csv(export_df)
    
    st.sidebar.download_button(
        label="Baixar Resultados como CSV",
        data=csv,
        file_name='resultados_comparativos_modelos.csv',
        mime='text/csv',
    )

# Informações do trabalho
st.sidebar.header("Informações")
st.sidebar.info("""
### Análise Comparativa de Modelos de Regressão em Grandes Datasets

**Dataset**: NYC Airbnb Open Data  
**Objetivo**: Analisar e comparar o desempenho de diferentes modelos de regressão e classificação

**Modelos Implementados**:
- Regressão Linear/Logística
- Árvore de Decisão
- Random Forest
- XGBoost
- SVR/SVM
- KNN
- Rede Neural (MLP)

**Métricas**: RMSE, R², Variância Explicada, Acurácia, F1-Score
""")
