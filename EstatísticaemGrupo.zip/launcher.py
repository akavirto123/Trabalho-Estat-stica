"""
Launcher simples para a aplicação de análise de modelos de regressão.
Este arquivo pode ser convertido em executável facilmente.
"""

import subprocess
import sys
import webbrowser
import time
import os
from pathlib import Path

def main():
    """Função principal do launcher."""
    print("=" * 60)
    print("    ANÁLISE COMPARATIVA DE MODELOS DE REGRESSÃO")
    print("=" * 60)
    print()
    
    # Verificar se estamos no diretório correto
    if not os.path.exists('app.py'):
        print("ERRO: Arquivo app.py não encontrado!")
        print("Certifique-se de que todos os arquivos estão na mesma pasta.")
        input("Pressione Enter para sair...")
        return
    
    print("Iniciando a aplicação...")
    print("Por favor, aguarde...")
    print()
    
    try:
        # Iniciar o Streamlit
        process = subprocess.Popen([
            sys.executable, "-m", "streamlit", "run", "app.py",
            "--server.port", "8501",
            "--server.address", "localhost",
            "--browser.gatherUsageStats", "false"
        ], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        
        # Aguardar um pouco para o servidor iniciar
        time.sleep(3)
        
        # Abrir o navegador
        print("Abrindo no navegador...")
        webbrowser.open('http://localhost:8501')
        
        print("✓ Aplicação iniciada com sucesso!")
        print()
        print("A aplicação está rodando em: http://localhost:8501")
        print()
        print("Para parar a aplicação:")
        print("- Feche esta janela")
        print("- Ou pressione Ctrl+C")
        print()
        print("=" * 60)
        
        # Manter o processo rodando
        try:
            process.wait()
        except KeyboardInterrupt:
            print("\nParando a aplicação...")
            process.terminate()
            
    except FileNotFoundError:
        print("ERRO: Python ou Streamlit não encontrado!")
        print()
        print("Por favor, instale as dependências primeiro:")
        print("pip install streamlit pandas numpy matplotlib seaborn scikit-learn xgboost")
        print()
        input("Pressione Enter para sair...")
        
    except Exception as e:
        print(f"ERRO: {e}")
        input("Pressione Enter para sair...")

if __name__ == "__main__":
    main()